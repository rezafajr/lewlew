<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\config;
use Illuminate\Support\Facades\Hash;

class configSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $config = new config();
        $config->z0 = '3';
        $config->a = '5';
        $config->c = '9';
        $config->m = '19';
        $config->save();
    }
}
