<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePengunjungTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Pengunjung', function (Blueprint $table) {
            $table->id();
            $table->string('bulan');
            $table->integer('t1')->nullable();
            $table->integer('t2')->nullable();
            $table->integer('t3')->nullable();
            $table->integer('t4')->nullable();
            $table->integer('t5')->nullable();
            $table->integer('t6')->nullable();
            $table->integer('t7')->nullable();
            $table->integer('t8')->nullable();
            $table->integer('t9')->nullable();
            $table->integer('t10')->nullable();
            $table->integer('t11')->nullable();
            $table->integer('t12')->nullable();
            $table->integer('t13')->nullable();
            $table->integer('t14')->nullable();
            $table->integer('t15')->nullable();
            $table->integer('t16')->nullable();
            $table->integer('t17')->nullable();
            $table->integer('t18')->nullable();
            $table->integer('t19')->nullable();
            $table->integer('t20')->nullable();
            $table->integer('t21')->nullable();
            $table->integer('t22')->nullable();
            $table->integer('t23')->nullable();
            $table->integer('t24')->nullable();
            $table->integer('t25')->nullable();
            $table->integer('t26')->nullable();
            $table->integer('t27')->nullable();
            $table->integer('t28')->nullable();
            $table->integer('t29')->nullable();
            $table->integer('t30')->nullable();
            $table->integer('t31')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Pengunjung');
    }
}
