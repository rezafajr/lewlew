<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHasilTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Hasil', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('pengunjung_id');
            $table->foreign('pengunjung_id')->references('id')->on('pengunjung')->constrained()->onDelete('cascade')->onUpdate('cascade');
            $table->string('data_prediksi');
            $table->text('mape');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Hasil');
    }
}
