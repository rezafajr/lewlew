<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Situ Cipanten</title>

    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        html {
            line-height: 1.15;
            -webkit-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        a {
            background-color: transparent
        }

        [hidden] {
            display: none
        }

        html {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            line-height: 1.5
        }

        *,
        :after,
        :before {
            box-sizing: border-box;
            border: 0 solid #e2e8f0
        }

        a {
            color: inherit;
            text-decoration: inherit
        }

        svg,
        video {
            max-width: 100%;
            height: auto
        }

        .bg-white {
            --bg-opacity: 1;
            background-color: #fff;
            background-color: rgba(255, 255, 255, var(--bg-opacity))
        }

        .bg-gray-100 {
            --bg-opacity: 1;
            background-color: #f7fafc;
            background-color: rgba(247, 250, 252, var(--bg-opacity))
        }

        .border-gray-200 {
            --border-opacity: 1;
            border-color: #edf2f7;
            border-color: rgba(237, 242, 247, var(--border-opacity))
        }

        .border-t {
            border-top-width: 1px
        }

        .flex {
            display: flex
        }

        .grid {
            display: grid
        }

        .hidden {
            display: none
        }

        .items-center {
            align-items: center
        }

        .justify-center {
            justify-content: center
        }

        .font-semibold {
            font-weight: 600
        }

        .h-5 {
            height: 1.25rem
        }

        .h-8 {
            height: 2rem
        }

        .h-16 {
            height: 4rem
        }

        .text-sm {
            font-size: .875rem
        }

        .text-lg {
            font-size: 1.125rem
        }

        .leading-7 {
            line-height: 1.75rem
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto
        }

        .ml-1 {
            margin-left: .25rem
        }

        .mt-2 {
            margin-top: .5rem
        }

        .mr-2 {
            margin-right: .5rem
        }

        .ml-2 {
            margin-left: .5rem
        }

        .mt-4 {
            margin-top: 1rem
        }

        .ml-4 {
            margin-left: 1rem
        }

        .mt-8 {
            margin-top: 2rem
        }

        .ml-12 {
            margin-left: 3rem
        }

        .-mt-px {
            margin-top: -1px
        }

        .max-w-6xl {
            max-width: 72rem
        }

        .min-h-screen {
            min-height: 100vh
        }

        .overflow-hidden {
            overflow: hidden
        }

        .p-6 {
            padding: 1.5rem
        }

        .py-4 {
            padding-top: 1rem;
            padding-bottom: 1rem
        }

        .px-6 {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }

        .pt-8 {
            padding-top: 2rem
        }

        .fixed {
            position: fixed
        }

        .relative {
            position: relative
        }

        .top-0 {
            top: 0
        }

        .right-0 {
            right: 0
        }

        .shadow {
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px 0 rgba(0, 0, 0, .06)
        }

        .text-center {
            text-align: center
        }

        .text-gray-200 {
            --text-opacity: 1;
            color: #edf2f7;
            color: rgba(237, 242, 247, var(--text-opacity))
        }

        .text-gray-300 {
            --text-opacity: 1;
            color: #e2e8f0;
            color: rgba(226, 232, 240, var(--text-opacity))
        }

        .text-gray-400 {
            --text-opacity: 1;
            color: #cbd5e0;
            color: rgba(203, 213, 224, var(--text-opacity))
        }

        .text-gray-500 {
            --text-opacity: 1;
            color: #a0aec0;
            color: rgba(160, 174, 192, var(--text-opacity))
        }

        .text-gray-600 {
            --text-opacity: 1;
            color: #718096;
            color: rgba(113, 128, 150, var(--text-opacity))
        }

        .text-gray-700 {
            --text-opacity: 1;
            color: #4a5568;
            color: rgba(74, 85, 104, var(--text-opacity))
        }

        .text-gray-900 {
            --text-opacity: 1;
            color: #1a202c;
            color: rgba(26, 32, 44, var(--text-opacity))
        }

        .underline {
            text-decoration: underline
        }

        .antialiased {
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        .w-5 {
            width: 1.25rem
        }

        .w-8 {
            width: 2rem
        }

        .w-auto {
            width: auto
        }

        .grid-cols-1 {
            grid-template-columns: repeat(1, minmax(0, 1fr))
        }

        @media (min-width:640px) {
            .sm\:rounded-lg {
                border-radius: .5rem
            }

            .sm\:block {
                display: block
            }

            .sm\:items-center {
                align-items: center
            }

            .sm\:justify-start {
                justify-content: flex-start
            }

            .sm\:justify-between {
                justify-content: space-between
            }

            .sm\:h-20 {
                height: 5rem
            }

            .sm\:ml-0 {
                margin-left: 0
            }

            .sm\:px-6 {
                padding-left: 1.5rem;
                padding-right: 1.5rem
            }

            .sm\:pt-0 {
                padding-top: 0
            }

            .sm\:text-left {
                text-align: left
            }

            .sm\:text-right {
                text-align: right
            }
        }

        @media (min-width:768px) {
            .md\:border-t-0 {
                border-top-width: 0
            }

            .md\:border-l {
                border-left-width: 1px
            }

            .md\:grid-cols-2 {
                grid-template-columns: repeat(2, minmax(0, 1fr))
            }
        }

        @media (min-width:1024px) {
            .lg\:px-8 {
                padding-left: 2rem;
                padding-right: 2rem
            }
        }

        @media (prefers-color-scheme:dark) {
            .bg-gray-800 {
                --bg-opacity: 1;
                background-color: #2d3748;
                background-color: rgba(45, 55, 72, var(--bg-opacity))
            }

            .bg-gray-900 {
                --bg-opacity: 1;
                background-color: #1a202c;
                background-color: rgba(26, 32, 44, var(--bg-opacity))
            }

            .dark\:border-gray-700 {
                --border-opacity: 1;
                border-color: #4a5568;
                border-color: rgba(74, 85, 104, var(--border-opacity))
            }

            .text-white {
                --text-opacity: 1;
                color: #fff;
                color: rgba(255, 255, 255, var(--text-opacity))
            }

            .dark\:text-gray-400 {
                --text-opacity: 1;
                color: #cbd5e0;
                color: rgba(203, 213, 224, var(--text-opacity))
            }

            .dark\:text-gray-500 {
                --tw-text-opacity: 1;
                color: #6b7280;
                color: rgba(107, 114, 128, var(--tw-text-opacity))
            }
        }
    </style>
    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        .main {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 95vh;
        }

        .carousel {
            --color-default-state: #ddd;
            --color-active-state: #1bb9ed;
            position: relative;
            height: 50vmin;
        }

        .carousel_track-container {
            overflow: hidden;
            width: 100%;
            height: 100%;
        }

        .carousel_track {
            position: relative;
            width: inherit;
            height: inherit;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .carousel_slide,
        .carousel_image {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            margin: 0;
            padding: 0;
        }

        .carousel_slide {
            padding: 5% 12% 8%;
            text-align: center;
            transform: translateX(-100%);
            transition: transform .3s ease-out;
        }

        .carousel_slide.is-selected {
            transform: translateX(0);
        }

        .carousel_slide.is-selected~.carousel_slide {
            transform: translateX(100%);
        }

        .carousel_image {
            z-index: -1;
        }

        .carousel_image>img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            border: none;
        }

        .carousel_title {
            font-size: 40px;
            color: #fff;
        }

        .carousel_btn,
        .carousel_dot {
            z-index: 1;
            padding: 0;
            cursor: pointer;
            border: none;
        }

        .carousel_btn {
            position: absolute;
            top: 50%;
            background-color: transparent;
            transform: translateY(-50%);
        }

        .carousel_btn:focus,
        .carousel_dot:focus,
        .carousel_btn:active,
        .carousel_dot:active {
            outline: none;
        }

        .carousel_btn>* {
            pointer-events: none;
        }

        .carousel_btn svg {
            fill: var(--color-default-state);
            transform-origin: center;
            transition: fill .2s;
        }

        .carousel_btn:hover svg {
            fill: var(--color-active-state);
        }

        .jsPrev {
            left: 10px;
        }

        .jsNext {
            right: 10px;
        }

        .jsPrev svg {
            transform: rotate(-90deg);
        }

        .jsNext svg {
            transform: rotate(90deg);
        }

        .carousel_nav {
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .carousel_dot {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background-color: var(--color-default-state);
            transition: background-color .2s;
        }

        .carousel_dot+.carousel_dot {
            margin-left: 20px;
        }

        .carousel_dot.is-selected {
            background-color: var(--color-active-state);
        }
    </style>

</head>

<body class="antialiased">
    <div class="relative flex items-top justify-center min-h-screen  bg-gray-900 sm:items-center py-4 sm:pt-0">
        @if (Route::has('login'))
        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
            <a href="{{ url('/') }}" class="text-sm text-white">Homepage</a>
            @auth
            <a href="{{ url('/dashboards') }}" class="ml-4 text-sm text-white">Dashboards</a>
            @else
            <a href="{{ route('login') }}" class="ml-4 text-sm text-white">Log in</a>
            @endauth
        </div>
        @endif
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="flex items-center" style="margin-top: 5%;">
                <img src="{{ asset('img/logo.png') }}" alt="Logo" style="width: 75px; height: 100px;">
                <div class="text-light" style="margin-left: 30px;color:white">
                    <h2>
                        Metode <b>Monte Carlo</b><br> Untuk memprediksi pengunjung wisata pada<br> "Situ Cipanten"
                    </h2>
                </div>
            </div>

            <div class="mt-8  bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                <div class="carousel">
                    <button type="button" class="carousel_btn jsPrev" aria-label="Previous slide">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                        </svg>
                    </button>

                    <div class="carousel_track-container">
                        <ul class="carousel_track">
                            <li class="carousel_slide is-selected">
                                <div class="carousel_image">
                                    <img src="{{ asset('img/situcipanten1.jpg') }}" style="border-radius: 10px;" alt="" role="presentation">
                                </div>
                            </li>
                            <li class="carousel_slide">
                                <div class="carousel_image">
                                    <img src="{{ asset('img/situcipanten2.jpg') }}" style="border-radius: 10px;" alt="" role="presentation">
                                </div>
                            </li>
                            <li class="carousel_slide">
                                <div class="carousel_image">
                                    <img src="{{ asset('img/situcipanten3.jpg') }}" style="border-radius: 10px;" alt="" role="presentation">
                                </div>
                            </li>
                        </ul>
                    </div>

                    <button type="button" class="carousel_btn jsNext" aria-label="Next slide">
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                        </svg>
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2">
                    <div class="p-6 border-t  border-gray-700">
                        <div class="flex items-center">
                            <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="w-8 h-8 text-gray-500">
                                <path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                            </svg>
                            <div class="ml-4 text-lg leading-7 font-semibold"><a href="#" class="text-white">Situ Cipanten</a></div>
                        </div>

                        <div class="ml-12">
                            <div class="mt-2  text-gray-400 text-sm">

                                Wisata danau alami dengan air biru yang jernih di Desa Gunung Kuning, Kecamatan Sindang, hanya 16 kilometer dari pusat Kota Majalengka.<br><br>

                                Fasilitas yang tersedia meliputi gazebo, dan tempat pertemuan serta terdapat berbagai wahana lainnya seperti bebek gowes, perahu dayung, dan sepeda gantung. Menariknya, warna air di Situ Cipanten bisa hijau saat musim kemarau dan berubah menjadi biru ketika musim hujan.

                            </div>
                        </div>
                    </div>

                    <div class="p-6 border-t  border-gray-700 md:border-l">
                        <div class="flex items-center">
                            <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="w-8 h-8 text-gray-500">
                                <path d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <div class="ml-4 text-lg leading-7 font-semibold  text-white">Lokasi & Harga</div>
                        </div>

                        <div class="ml-12">
                            <div class="mt-2  text-gray-400 text-sm">
                                Jl. Gn. Kuning - Sindang, Gn. Kuning, Kec. Sindang, Kabupaten Majalengka, Jawa Barat 45471, Indonesia<br>
                                ---<br>
                                Tiket masuk Rp 10.000/orang <br>
                                Kapal dayung atau Pelampung Rp 10.000/ orang<br>
                                Bebek goes Rp 20.000/ orang<br>
                                Sepeda gantung Rp 25.000/ orang ,dll
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex justify-center mt-4 sm:items-center sm:justify-between">
                <div class="text-center text-sm text-gray-500 sm:text-left">
                    <div class="flex items-center">
                        <a class="ml-1 underline">
                            <svg width="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M15.85 2.50065C16.481 2.50065 17.111 2.58965 17.71 2.79065C21.401 3.99065 22.731 8.04065 21.62 11.5806C20.99 13.3896 19.96 15.0406 18.611 16.3896C16.68 18.2596 14.561 19.9196 12.28 21.3496L12.03 21.5006L11.77 21.3396C9.48102 19.9196 7.35002 18.2596 5.40102 16.3796C4.06102 15.0306 3.03002 13.3896 2.39002 11.5806C1.26002 8.04065 2.59002 3.99065 6.32102 2.76965C6.61102 2.66965 6.91002 2.59965 7.21002 2.56065H7.33002C7.61102 2.51965 7.89002 2.50065 8.17002 2.50065H8.28002C8.91002 2.51965 9.52002 2.62965 10.111 2.83065H10.17C10.21 2.84965 10.24 2.87065 10.26 2.88965C10.481 2.96065 10.69 3.04065 10.89 3.15065L11.27 3.32065C11.3618 3.36962 11.4649 3.44445 11.554 3.50912C11.6104 3.55009 11.6612 3.58699 11.7 3.61065C11.7163 3.62028 11.7329 3.62996 11.7496 3.63972C11.8354 3.68977 11.9247 3.74191 12 3.79965C13.111 2.95065 14.46 2.49065 15.85 2.50065ZM18.51 9.70065C18.92 9.68965 19.27 9.36065 19.3 8.93965V8.82065C19.33 7.41965 18.481 6.15065 17.19 5.66065C16.78 5.51965 16.33 5.74065 16.18 6.16065C16.04 6.58065 16.26 7.04065 16.68 7.18965C17.321 7.42965 17.75 8.06065 17.75 8.75965V8.79065C17.731 9.01965 17.8 9.24065 17.94 9.41065C18.08 9.58065 18.29 9.67965 18.51 9.70065Z" fill="currentColor"></path>
                            </svg>
                        </a>
                    </div>
                </div>

                <div class="ml-4 text-center text-sm text-gray-500 sm:text-right sm:ml-0">
                    Laravel v{{ Illuminate\Foundation\Application::VERSION }} (PHP v{{ PHP_VERSION }})
                </div>
            </div>
        </div>
    </div>
    <script>
        const carousel = document.querySelector('.carousel')
        const slider = carousel.querySelector('.carousel_track')
        let slides = [...slider.children]

        // Initial slides position, so user can go from first to last slide (click to the left first)
        slider.prepend(slides[slides.length - 1])

        // Creating dot for each slide
        const createDots = (carousel, initSlides) => {
            const dotsContainer = document.createElement('div')
            dotsContainer.classList.add('carousel_nav')

            initSlides.forEach((slide, index) => {
                const dot = document.createElement('button')
                dot.type = 'button'
                dot.classList.add('carousel_dot')
                dot.setAttribute('aria-label', `Slide number ${index + 1}`)
                slide.dataset.position = index
                slide.classList.contains('is-selected') && dot.classList.add('is-selected')
                dotsContainer.appendChild(dot)
            })

            carousel.appendChild(dotsContainer)

            return dotsContainer
        }

        // Updating relevant dot
        const updateDot = slide => {
            const currDot = dotNav.querySelector('.is-selected')
            const targetDot = slide.dataset.position

            currDot.classList.remove('is-selected')
            dots[targetDot].classList.add('is-selected')
        }

        // Handling arrow buttons
        const handleArrowClick = arrow => {
            arrow.addEventListener('click', () => {
                slides = [...slider.children]
                const currSlide = slider.querySelector('.is-selected')
                currSlide.classList.remove('is-selected')
                let targetSlide

                if (arrow.classList.contains('jsPrev')) {
                    targetSlide = currSlide.previousElementSibling
                    slider.prepend(slides[slides.length - 1])
                }

                if (arrow.classList.contains('jsNext')) {
                    targetSlide = currSlide.nextElementSibling
                    slider.append(slides[0])
                }

                targetSlide.classList.add('is-selected')
                updateDot(targetSlide)
            })
        }

        const buttons = carousel.querySelectorAll('.carousel_btn')
        buttons.forEach(handleArrowClick)

        // Handling dot buttons
        const handleDotClick = dot => {
            const dotIndex = dots.indexOf(dot)
            const currSlidePos = slider.querySelector('.is-selected').dataset.position
            const targetSlidePos = slider.querySelector(`[data-position='${dotIndex}']`).dataset.position

            if (currSlidePos < targetSlidePos) {
                const count = targetSlidePos - currSlidePos
                for (let i = count; i > 0; i--) nextBtn.click()
            }

            if (currSlidePos > targetSlidePos) {
                const count = currSlidePos - targetSlidePos
                for (let i = count; i > 0; i--) prevBtn.click()
            }
        }

        const dotNav = createDots(carousel, slides)
        const dots = [...dotNav.children]
        const prevBtn = buttons[0]
        const nextBtn = buttons[1]

        dotNav.addEventListener('click', e => {
            const dot = e.target.closest('button')
            if (!dot) return
            handleDotClick(dot)
        })

        // Auto sliding
        const slideTiming = 5000
        let interval
        const slideInterval = () => interval = setInterval(() => nextBtn.click(), slideTiming)

        carousel.addEventListener('mouseover', () => clearInterval(interval))
        carousel.addEventListener('mouseleave', slideInterval)
        slideInterval()
    </script>
</body>

</html>