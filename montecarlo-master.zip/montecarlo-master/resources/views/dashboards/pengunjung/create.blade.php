@extends('layouts.dashboard')

@section('title')
{{'Pengunjung create'}}
@endsection

@section('content')
@if(isset($duplikat))

<div class="alert alert-danger" role="alert">
    <label class="col-md-12  label-control mb-2" for="art_no"> Data pengunjung sudah ada </label>
</div>
@endif
<div class="card">
    <div class="card-content collpase show">
        <div class="card-body">
            <form action="{{ route('pengunjung.store') }}" class="form form-horizontal" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-body">
                    <div class="col-lg-12">
                        <div class="form-group row">
                            <label class="col-md-2 label-control text-left" for="userinput1">bulan</label>
                            <div class="col-md-10">
                                <input required type="text" id="bulan" class="form-control border-primary" placeholder="bulan" name="bulan" value="{{old('bulan')}}">
                            </div>
                        </div>
                    </div>
                    @for($i=1;$i<=31;$i++) <div class="col-lg-12">
                        <div class="form-group row">
                            <label class="col-md-2 label-controltext-left" for="userinput2">Tanggal {{$i}} </label>
                            <div class="col-md-10">
                                <input min=0 type="number" id="t{{$i}}" name="t{{$i}}" placeholder="Tanggal {{$i}}" class="form-control border-primary"  >
                            </div>
                        </div>
                        @endfor
                </div>

                <div class="d-flex justify-content-center p-3">
                    <button type="submit" class="btn btn-primary">
                        <i data-feather="save" class="icon"></i> Create
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
    $("#bulan").datepicker({
        format: "yyyy-mm",
        startView: "months",
        minViewMode: "months",
        startDate: "2000-01",
        endDate: '2100-012',
    }).on("change", function(event) {
        $(".datepicker-dropdown").each(function(index, element) {
            $(element).hide();
        });
    });
</script>
@endsection