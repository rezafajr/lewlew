@extends('layouts.dashboard')

@section('title')
{{'Pengunjung View'}}
@endsection

@section('content')

<div class="col-md-12">
    <div class="card">
        <div class="card-content collpase show">
            <div class="card-body">
                <div class="form-body table-responsive">
                    <table class="table "  >
                        <tbody>
                            <?php
                            $data = explode('-', $pengunjung->bulan);
                            $datatahun = $data[0];
                            $databulan = $data[1];
                            if ($databulan == '01' || $databulan == '03' || $databulan == '05' || $databulan == '07' || $databulan == '08' || $databulan == '10' || $databulan == '12') {
                                $jumlahhari = 31;
                            } elseif ($databulan == '04' || $databulan == '06' || $databulan == '09' || $databulan == '11') {
                                $jumlahhari = 30;
                            } else {
                                if ($datatahun % 4 == 0) {
                                    $jumlahhari = 28;
                                } elseif ($datatahun % 4 != 0) {
                                    $jumlahhari = 29;
                                }
                            }
                            ?>
                            <tr>
                                <td><b>
                                        <h1> Bulan
                                    </b></h1>
                                </td>
                                <td><b>
                                        <h1> {{ $pengunjung->bulan }}
                                    </b></h1>
                                </td>
                            </tr> 
                            @for ($i = 1; $i <= $jumlahhari; $i++) 
                            <tr>
                                <td> Tanggal {{ $i}}
                                <td><?php echo $pengunjung->{'t' . $i};   ?> </td>
                            </tr>
                                @endfor
                                
                            <tr>
                                <td><b>
                                        <h1> Jumlah Pengunjung
                                    </b></h1>
                                </td>
                                <td><b>
                                        <h1>{{ $jumlah }}
                                    </b></h1>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
                <div class="d-flex justify-content-center p-3">
                    <a class="btn btn-secondary ml-1 mt-2" href="/dashboards/pengunjung"><i data-feather="arrow-left" class="icon"></i>Back </a>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection