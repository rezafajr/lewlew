@extends('layouts.dashboard')

@section('title')
{{'Pengunjung Edit'}}
@endsection

@section('content')

<div class="card">
    <div class="card-content collpase show">
        <div class="card-body">
            <form action="{{ route('pengunjung.update',$pengunjung->id) }}" class="form form-horizontal" method="POST">
                @csrf
                @method('PUT')
                <div class="form-body">
                    <div class="col-lg-12">
                        <div class="form-group row">
                            <label class="col-md-2 label-control text-left" for="userinput1">bulan</label>
                            <div class="col-md-10">
                                <input required type="text" readonly id="bulan" value="{{$pengunjung->bulan}} " class="form-control border-primary" placeholder="bulan" name="bulan">
                            </div>
                        </div>
                    </div>
                    @for($i=1;$i<=$jumlahhari;$i++) <div class="col-lg-12">
                        <div class="form-group row">
                            <label class="col-md-2 label-controltext-left" for="userinput2">Tanggal {{$i}} </label>
                            <div class="col-md-10">
                                <input min=0 type="number" id="t{{$i}}" name="t{{$i}}" placeholder="Tanggal {{$i}}" class="form-control border-primary" value="<?php echo $pengunjung->{'t' . $i} ?>">
                            </div>
                        </div>
                        @endfor
                </div>
        </div>

        <div class="d-flex justify-content-center p-3">
            <button type="submit" class="btn btn-primary">
                <i data-feather="save" class="icon"></i> Update
            </button>
        </div>
        </form>
    </div>
    </div>




    <script>
    $("#bulan").datepicker({
        format: "yyyy-mm",
        startView: "months",
        minViewMode: "months",
        startDate: "2000-01",
        endDate: '2100-012',
    }).on("change", function(event) {
        $(".datepicker-dropdown").each(function(index, element) {
            $(element).hide();
        });
    });
</script>

    @endsection