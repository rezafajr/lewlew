@extends('layouts.dashboard')

@section('title')
{{'Dashboard'}}
@endsection

@section('content')
<div class="row justify-content-center">
    <div class="card">
        <div class="card-body">
            <div class="text-center">
                <h3>
                    Metode <b>Monte Carlo</b> Untuk memprediksi pengunjung wisata pada <br> Situ Cipanten
                </h3>
            </div>
        </div>
    </div>
</div>
@endsection