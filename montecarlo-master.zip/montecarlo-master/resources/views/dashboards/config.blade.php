@extends('layouts.dashboard')

@section('title')
{{'Config'}}
@endsection

@section('content')

@if ($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif
<div class="col-md-12">
    <div class="card">
        <div class="card-content collpase show">
            <div class="card-body">
                
                <form method="POST" action="{{ url('/dashboards/config') }}">
                    @method('patch')
                    @csrf
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">Z0</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="z0" value="{{ $config->z0 }}">

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">A</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="a" value="{{ $config->a }}">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">C</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="c" value="{{ $config->c }}">

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">M</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="m" value="{{ $config->m }}">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center p-3">
                        <button type="submit" class="btn btn-primary">
                            <i data-feather="save" class="icon"></i> Update
                        </button>
                    </div>
                </form>
                <div class="alert alert-info mt-3" role="alert">
                    <i data-feather="info"></i>
                    <strong>Informasi:</strong><br><br>
                    Zi/Z0 = Bilangan Sementara ke-i dari deretnya (index ke-0)<br>
                    A = Konstanta perkalian / faktor pengali<br>
                    C = Increment<br>
                    M = Konstanta penambahan<br>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection



@push('scripts')
<script type="text/javascript">
    $(document).ready(function() {
        $("input").attr("readonly", true);

        $("#image").prop("disabled", true);
    })
    $("#btnubah").click(function(event) {
        event.preventDefault();
        document.getElementById('ubah').classList.add('hidden');
        document.getElementById('batal').classList.remove('hidden');
        $("input").attr("readonly", false);
        $("#image").prop("disabled", false);

    });

    $("#btnbatal").click(function(event) {
        event.preventDefault();
        document.getElementById('ubah').classList.remove('hidden');
        document.getElementById('batal').classList.add('hidden');
        $("input").attr("readonly", true);
        $("#image").prop("disabled", true);

    });
</script>
@endpush