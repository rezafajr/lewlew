<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .laporan-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .laporan-header h1 {
            font-size: 24px;
        }

        .laporan-details {
            margin-bottom: 20px;
        }

        .laporan-details p {
            margin: 5px;
        }

        .laporan-table {
            width: 100%;
            border-collapse: collapse;
        }

        .laporan-table th,
        .laporan-table td {
            border: 1px solid #000;
            padding: 8px;
        }
    </style>
</head>

<body>
    <div class="laporan-container">
        <div class="laporan-header">
            <h1>LAPORAN</h1>
            <p>Tanggal: <?php echo date('j F  Y'); ?></p>
        </div>
        @if($data['dataprediksi']=='bulan')
            <div class="laporan-details">
                @php
                    $pengunjung = json_decode($data['pengunjung']);
                @endphp
                <p>Jenis Data Prediksi: <b>{{$data['dataprediksi']}}</b> </p>
                <p>Data Perhitungan: <b>{{ $pengunjung->bulan }}</b></p>

            </div>
            <div class="form-body" id="div4">
                <h4 class="form-section mt-5 mb-2"><i class="ft-cpu"></i> Prediksi Pengunjung</h4>
                <div id="tb_product_wrapper">
                    <table class="laporan-table">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Prediksi Pengunjung</th>
                                <th>Total Pengunjung Asli</th>
                                <th>APE</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                            $hasilprediksi = json_decode($data['hasilprediksi']);
                            $dataasli = json_decode($data['dataasli']); // Corrected variable name
                            $ape = json_decode($data['ape']);
                            @endphp

                            @for ($i = 1; $i <= $data['jumlahharibulandepan']; $i++) <tr>
                                <td>{{ $i }}</td>
                                <td>{{ isset($hasilprediksi->$i) ? $hasilprediksi->$i : "0" }} </td>
                                @if (!isset($dataaslibelumada))
                                <td>{{ isset($dataasli->$i) ? $dataasli->$i : 0 }}
                                <td>{{ isset($ape->$i) ? round($ape->$i,3) : 0 }}
                                    @else
                                <td>0</td>
                                <td>0</td>
                                @endif
                                </tr>
                                @endfor
                                <th></th>
                            <th>Total: {{$data['totalprediksi']}} </th>
                            @if ( !isset($dataaslibelumada))
                            <th>Total: {{$data['totaldataasli']}} </th>
                            <th>MAPE: {{round($data['mape'],4)}}% </th>
                            @else
                            <th>Total: 0</th>
                            <th>MAPE: 0</th>
                            @endif
                        </tbody>
                    </table>


                </div>
            </div> 
        @else
        <div class="laporan-details"> 
                <p>Jenis Data Prediksi: <b>{{$data['dataprediksi']}}</b> </p>
                <p>Data Perhitungan: <b>{{ $data['triwulan'] }}</b></p>
            </div>
           
        <div class="form-body" id="div4">
            <div id="tb_product_wrapper">
            <table class="laporan-table">
                    <thead>
                        <tr>
                            <th>Bulan Pada {{$data['triwulan']}}</th>
                            <th>Prediksi Permintaan</th>
                            <th>Total Permintaan Asli</th>
                            <th>APE</th>
                        </tr>
                    </thead>
                    <tbody>
                            @php
                            $hasilprediksi = json_decode($data['hasilprediksi']);
                            $dataasli = json_decode($data['dataasli']); // Corrected variable name
                            $ape = json_decode($data['ape']);
                            @endphp

                            @for ($i = 1; $i <= 3; $i++) <tr> 
                            <td>{{$i}}</td>

                                <td>{{ isset($hasilprediksi->$i) ? $hasilprediksi->$i : "0" }} </td>
                                @if (!isset($dataaslibelumada))
                                <td>{{ isset($dataasli->$i) ? $dataasli->$i : "0" }}
                                <td>{{ isset($ape->$i) ? $ape->$i : "0" }}
                                @endif
                                </tr>
                                @endfor  
                            <th></th>
                            <th>Total: {{$data['totalprediksi']}} </th>
                            @if ( !isset($dataaslibelumada))
                            <th>Total: {{$data['totaldataasli']}} </th>
                            <th>MAPE: {{$data['mape']}}% </th>
                            @else
                            <th>Total: 0</th>
                            <th>MAPE: 0</th>
                            @endif
                        </tbody>
                </table>

            </div>
        </div>
        @endif
    </div>
</body>

</html>