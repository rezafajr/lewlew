@extends('layouts.dashboard')

@section('title')
{{'Hasil View'}}
@endsection

@section('content')
<?php
$data = json_decode($hasil->mape, true);
// dd($data);
?>
<div class="col-md-12">
    <div class="card">
        <div class="card-content collpase show">
            <div class="card-body">
                <div class="form-body table-responsive">

                    <h1> Data Perhitungan : <b>{{ $data['dataprediksi'] }} </b></h1>
                    <br>
                    <table class="table mt-4 ">
                        <tbody>
                            <thead>
                                <td> Tanggal </td>
                                <td> Prediksi Pengunjung </td>
                                <td> Pengunjung Asli </td>
                                <td> APE </td>
                            </thead>
                            @for ($i = 1; $i <=count($data['hasilprediksi']) ; $i++) <tr>
                                <td>{{ $i}}
                                <td><?php echo  $data['hasilprediksi'][$i];   ?> </td>
                                <td><?php echo  $data['dataasli'][$i];   ?> </td>
                                <td><?php echo  $data['ape'][$i];   ?> </td>
                                </tr>
                                @endfor
                                <tr>
                                    <td> Jumlah Prediksi Pengunjung </td>
                                    <td> Total:{{ $data['totalprediksi']   }} </td>
                                    <td> Total:{{ $data['totaldataasli']   }} </td>
                                    <td>MAPE: {{ $data['mape']   }} % </td>
                                </tr>
                        </tbody>
                    </table>

                </div>
                <div class="d-flex justify-content-center p-3">
                    <a class="btn btn-secondary ml-1 mt-2" href="/dashboards/hasil"><i data-feather="arrow-left" class="icon"></i>Back </a>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection