@extends('layouts.dashboard')

@section('title')
{{'hasil'}}
@endsection

@section('content')
<div class="card">
  <div class="card-content">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table dataTable">
          <thead>
            <tr role="row">
              <th>Id</th>
              <th>Pengunjung_id</th>
              <th>Data Prediksi</th>
              <th>Mape</th>
              <th>Timestamp</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @foreach($hasil as $no =>$row)
            <tr role="row" class="odd">
              <td>{{$no+1}}</td>
              <td>{{$row -> pengunjung_id}}</td>
              <td>{{$row -> data_prediksi}}</td>
              <?php 
              $data = json_decode($row -> mape, true);
              ?>
              <td>{{$data['mape']}}%</td>
              <td>{{$row -> updated_at -> diffForHumans();}}</td>
              <td>
                <form action="{{ route('hasil.destroy',$row->id) }}" method="POST">
                  @csrf
                  @method('DELETE')
                  <a class="btn btn-info btn-sm" href="{{ URL::to('dashboards/hasil/'.$row -> id)}}"><i data-feather="eye" class="icon"></i></a>
                  <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm"><i data-feather="trash" class="icon"></i></button>
                </form>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>

      </div>
    </div>
  </div>
</div>
<script>
 feather.replace()
    $('.dataTable').dataTable({
        "pageLength": 25
    });
</script>

@endsection