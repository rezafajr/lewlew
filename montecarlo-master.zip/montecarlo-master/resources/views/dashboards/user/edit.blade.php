@extends('layouts.dashboard')

@section('title')
{{'Users Edit'}}
@endsection
@section('content')
<div class="col-md-12">
    <div class="card"> 
        <div class="card-content collpase show">
            <div class="card-body">
                <form action="{{ route('users.update', $user->id) }}" class="form form-horizontal" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="form-body">

                        <h4 class="form-section mt-2"><i class="ft-paperclip"></i> About User</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Name</label>
                                    <div class="col-md-9">
                                        <input required type="text" id="name" value="{{ $user->name }} " class="form-control border-primary" placeholder="name" name="name">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Email</label>
                                    <div class="col-md-9">
                                        <input required type="text" id="email" value="{{ $user->email }} " class="form-control border-primary" placeholder="email" name="email">
                                        @error('email')
                                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                                        @enderror
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Password</label>
                                    <div class="col-md-9">
                                        <input type="password" required id="password" class="form-control border-primary" placeholder="password" name="password">
                                        @error('password')
                                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                                        @enderror
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Level</label>
                                    <div class="col-md-9">
                                        &nbsp;&nbsp;
                                        <input type="radio" name="level" value="1" {{ $user->level == 1 ? 'checked' : '' }}> Administrator
                                        &nbsp;&nbsp;
                                        <input type="radio" name="level" value="2" {{ $user->level == 2 ? 'checked' : '' }}> Pengguna
                                        &nbsp;&nbsp;
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    <div class="d-flex justify-content-center p-3">
                        <button type="submit" class="btn btn-primary">
                            <i data-feather="save" class="icon"></i> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>

@endsection