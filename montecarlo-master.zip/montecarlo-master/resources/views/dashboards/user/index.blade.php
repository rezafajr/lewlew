@extends('layouts.dashboard')

@section('title')
{{'Users'}}
@endsection

@section('content')
<div class="card">
  <div class="card-content">
    <div class="card-body">
      <div class="table-responsive">
        <div class="d-flex justify-content-center p-3">
          <a class="btn btn-success ml-1" href="/dashboards/users/create"><i data-feather="plus" class="icon"></i> Add</a>
        </div>
        <table class="table dataTable">
          <thead>
            <tr role="row">
              <th>Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @foreach($user as $no =>$row)
            <tr role="row" class="odd">
              <td>{{$no+1}}</td>
              <td>{{$row -> name}}</td>
              <td>{{$row -> email}}</td>
              <td>{{$row -> level == 1?"Administrator":"Pengguna"}}</td>
              <td>
                <form action="{{ route('users.destroy',$row->id) }}" method="POST">
                  <a class="btn btn-info btn-sm" href="{{ URL::to('dashboards/users/'.$row -> id)}}"><i data-feather="eye" class="icon"></i></a>
                  <a class="btn btn-primary btn-sm" href="{{ URL::to('dashboards/users/'.$row -> id.'/edit/')}}"><i data-feather="edit" class="icon"></i></a>
                  @csrf
                  @method('DELETE')
                  <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm"><i data-feather="trash" class="icon"></i></button>
                </form>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>

      </div>
    </div>
  </div>
</div>
<script>
 feather.replace()
    $('.dataTable').dataTable({
        "pageLength": 25
    });
</script>

@endsection