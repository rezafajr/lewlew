@extends('layouts.dashboard')

@section('title')
{{'Users Create'}}
@endsection

@section('content') 
<div class="col-md-12">
    <div class="card">
        <div class="card-content collpase show">
            <div class="card-body">
                <form action="{{ route('users.store') }}" class="form form-horizontal" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Name</label>
                                    <div class="col-md-9">
                                        <input required type="text" id="name" class="form-control border-primary" placeholder="name" name="name">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Email</label>
                                    <div class="col-md-9">
                                        <input required type="text" id="email" class="form-control border-primary" placeholder="email" name="email">
                                        @error('email')
                                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Password</label>
                                    <div class="col-md-9">
                                        <input required type="password" id="password" class="form-control border-primary" placeholder="password" name="password">
                                        @error('password')
                                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">level</label>
                                    <div class="col-md-9">
                                        <input required type="radio" id="level1" name="level" value="1">
                                        <label class="label-control" for="level1">Administrator</label>
                                        &nbsp;&nbsp;
                                        <input required type="radio" id="level2" name="level" value="2">
                                        <label class="label-control" for="level2" selected>Pengguna</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center p-3">
                        <button type="submit" class="btn btn-primary">
                            <i data-feather="save" class="icon"></i> Save
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>


@endsection