@extends('layouts.dashboard')

@section('title')
{{'Users View'}}
@endsection

@section('content')
<div class="col-md-12">
  <div class="card"> 
    <div class="card-content collpase show">
      <div class="card-body">

        <div class="form-body">
          <table class="table  dataTable " id="tb_product" role="grid">
            <tr>
              <td><b>Name:</b></td>
              <td>{{ $user->name }}</td>
            </tr>
            <tr>
              <td><b>Email:</b></td>
              <td>{{ $user->email }}</td>
            </tr>
            <tr>
              <td><b>Level:</b></td>
              <td>{{$user -> level == 1?"Administrator":"Pengguna"}}</td>
            </tr>

          </table>
          <div class="d-flex justify-content-center p-3">
                    <a class="btn btn-secondary ml-1 mt-2" href="/dashboards/users"><i data-feather="arrow-left" class="icon"></i> Go Back </a>
                </div>
        </div>
      </div>
    </div>
  </div>
</div>



@endsection