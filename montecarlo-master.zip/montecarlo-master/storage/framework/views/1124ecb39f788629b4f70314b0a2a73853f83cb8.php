<?php $__env->startSection('title'); ?>
<?php echo e('Pengunjung create'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(isset($duplikat)): ?>

<div class="alert alert-danger" role="alert">
    <label class="col-md-12  label-control mb-2" for="art_no"> Data pengunjung sudah ada </label>
</div>
<?php endif; ?>
<div class="card">
    <div class="card-content collpase show">
        <div class="card-body">
            <form action="<?php echo e(route('pengunjung.store')); ?>" class="form form-horizontal" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-body">
                    <div class="col-lg-12">
                        <div class="form-group row">
                            <label class="col-md-2 label-control text-left" for="userinput1">bulan</label>
                            <div class="col-md-10">
                                <input required type="text" id="bulan" class="form-control border-primary" placeholder="bulan" name="bulan" value="<?php echo e(old('bulan')); ?>">
                            </div>
                        </div>
                    </div>
                    <?php for($i=1;$i<=31;$i++): ?> <div class="col-lg-12">
                        <div class="form-group row">
                            <label class="col-md-2 label-controltext-left" for="userinput2">Tanggal <?php echo e($i); ?> </label>
                            <div class="col-md-10">
                                <input min=0 type="number" id="t<?php echo e($i); ?>" name="t<?php echo e($i); ?>" placeholder="Tanggal <?php echo e($i); ?>" class="form-control border-primary"  >
                            </div>
                        </div>
                        <?php endfor; ?>
                </div>

                <div class="d-flex justify-content-center p-3">
                    <button type="submit" class="btn btn-primary">
                        <i data-feather="save" class="icon"></i> Create
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<script>
    $("#bulan").datepicker({
        format: "yyyy-mm",
        startView: "months",
        minViewMode: "months",
        startDate: "2000-01",
        endDate: '2100-012',
    }).on("change", function(event) {
        $(".datepicker-dropdown").each(function(index, element) {
            $(element).hide();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/pengunjung/create.blade.php ENDPATH**/ ?>