<?php $__env->startSection('title'); ?>
<?php echo e('Config'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-content collpase show">
            <div class="card-body">
                
                <form method="POST" action="<?php echo e(url('/dashboards/config')); ?>">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">Z0</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="z0" value="<?php echo e($config->z0); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">A</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="a" value="<?php echo e($config->a); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">C</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="c" value="<?php echo e($config->c); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="configinput1">M</label>
                                    <div class="col-md-9">
                                        <input required type="number" class="form-control border-primary" name="m" value="<?php echo e($config->m); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center p-3">
                        <button type="submit" class="btn btn-primary">
                            <i data-feather="save" class="icon"></i> Update
                        </button>
                    </div>
                </form>
                <div class="alert alert-info mt-3" role="alert">
                    <i data-feather="info"></i>
                    <strong>Informasi:</strong><br><br>
                    Zi/Z0 = Bilangan Sementara ke-i dari deretnya (index ke-0)<br>
                    A = Konstanta perkalian / faktor pengali<br>
                    C = Increment<br>
                    M = Konstanta penambahan<br>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $("input").attr("readonly", true);

        $("#image").prop("disabled", true);
    })
    $("#btnubah").click(function(event) {
        event.preventDefault();
        document.getElementById('ubah').classList.add('hidden');
        document.getElementById('batal').classList.remove('hidden');
        $("input").attr("readonly", false);
        $("#image").prop("disabled", false);

    });

    $("#btnbatal").click(function(event) {
        event.preventDefault();
        document.getElementById('ubah').classList.remove('hidden');
        document.getElementById('batal').classList.add('hidden');
        $("input").attr("readonly", true);
        $("#image").prop("disabled", true);

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/config.blade.php ENDPATH**/ ?>