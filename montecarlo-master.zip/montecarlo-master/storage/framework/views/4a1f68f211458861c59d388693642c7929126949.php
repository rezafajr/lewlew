<?php $__env->startSection('title'); ?>
<?php echo e('Dashboard'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="card">
        <div class="card-body">
            <div class="text-center">
                <h3>
                    Metode <b>Monte Carlo</b> Untuk memprediksi pengunjung wisata pada <br> Situ Cipanten
                </h3>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/dashboards.blade.php ENDPATH**/ ?>