<?php $__env->startSection('title'); ?>
<?php echo e('Hasil View'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
$data = json_decode($hasil->mape, true);
// dd($data);
?>
<div class="col-md-12">
    <div class="card">
        <div class="card-content collpase show">
            <div class="card-body">
                <div class="form-body table-responsive">

                    <h1> Data Perhitungan : <b><?php echo e($data['dataprediksi']); ?> </b></h1>
                    <br> 
                    <table class="table mt-4 ">
                        <tbody>
                            <thead>
                                <td> Tanggal </td>
                                <td> Prediksi Permintaan </td>
                                <td> Permintaan Asli </td>
                                <td> APE </td>
                            </thead>
                            <?php for($i = 1; $i <=count($data['hasilprediksi']) ; $i++): ?> <tr>
                                <td><?php echo e($i); ?>

                                <td><?php echo  $data['hasilprediksi'][$i];   ?> </td>
                                <td><?php echo  $data['dataasli'][$i];   ?> </td>
                                <td><?php echo  $data['ape'][$i];   ?> </td>
                                </tr>
                                <?php endfor; ?>
                                <tr>
                                    <td> Jumlah Prediksi Pengunjung </td>
                                    <td> Total:<?php echo e($data['totalprediksi']); ?> </td>
                                    <td> Total:<?php echo e($data['totaldataasli']); ?> </td>
                                    <td>MAPE: <?php echo e($data['mape']); ?> % </td>
                                </tr>
                        </tbody>
                    </table>

                </div>
                <div class="d-flex justify-content-center p-3">
                    <a class="btn btn-secondary ml-1 mt-2" href="/dashboards/hasil"><i data-feather="arrow-left" class="icon"></i>Back </a>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/hasil/view.blade.php ENDPATH**/ ?>