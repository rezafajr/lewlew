<?php $__env->startSection('title'); ?>
<?php echo e('Users'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-content">
    <div class="card-body">
      <div class="table-responsive">
        <div class="d-flex justify-content-center p-3">
          <a class="btn btn-success ml-1" href="/dashboards/users/create"><i data-feather="plus" class="icon"></i> Add</a>
        </div>
        <table class="table dataTable">
          <thead>
            <tr role="row">
              <th>Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no =>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr role="row" class="odd">
              <td><?php echo e($no+1); ?></td>
              <td><?php echo e($row -> name); ?></td>
              <td><?php echo e($row -> email); ?></td>
              <td><?php echo e($row -> level == 1?"Administrator":"Pengguna"); ?></td>
              <td>
                <form action="<?php echo e(route('users.destroy',$row->id)); ?>" method="POST">
                  <a class="btn btn-info btn-sm" href="<?php echo e(URL::to('dashboards/users/'.$row -> id)); ?>"><i data-feather="eye" class="icon"></i></a>
                  <a class="btn btn-primary btn-sm" href="<?php echo e(URL::to('dashboards/users/'.$row -> id.'/edit/')); ?>"><i data-feather="edit" class="icon"></i></a>
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm"><i data-feather="trash" class="icon"></i></button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

      </div>
    </div>
  </div>
</div>
<script>
 feather.replace()
    $('.dataTable').dataTable({
        "pageLength": 25
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/user/index.blade.php ENDPATH**/ ?>