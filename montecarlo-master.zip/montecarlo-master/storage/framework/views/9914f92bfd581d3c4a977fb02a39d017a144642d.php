<!doctype html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <title>Situ Cipanten</title>
   <link rel="stylesheet" href="<?php echo e(asset('dashboard/')); ?>/assets/css/libs.min.css">
   <link rel="stylesheet" href="<?php echo e(asset('dashboard/')); ?>/assets/css/coinex.css?v=1.0.0">
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/feather.min.js"></script>
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/jquery-3.7.0.js"></script>
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/jquery.dataTables.min.js"></script>
   <link rel="stylesheet" href="<?php echo e(asset('/dashboard/assets/vendor/datepicker/datepicker.min.css')); ?>">
   <script src="<?php echo e(asset('/dashboard/assets/vendor/datepicker/bootstrap-datepicker.min.js')); ?>"></script>
   <script src="<?php echo e(asset('/dashboard/assets/vendor/datepicker/bootstrap-checkbox.min.js')); ?>"></script>
   <script src="<?php echo e(asset('/dashboard/assets/js/moment.min.js')); ?>"></script>

   <style>
      .icon {
         width: 16px;
         height: 16px;
      }

      .datepicker table tr td span {
         width: 100%
      }
   </style>
   <script>
      feather.replace()
   </script>
</head>

<body class=" ">
   <div class="bg-dark">
      <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>

   <aside class="sidebar sidebar-default navs-rounded ">
      <div class="sidebar-header d-flex align-items-center justify-content-start">
         <a class="navbar-brand dis-none align-items-center justify-content-center">
            <img src="<?php echo e(asset('img/logo.png')); ?>" class="mx-2" width="35px">
            <h4 class="logo-title m-0 px-1">Situ Cipanten</h4>
         </a>
         <div class="sidebar-toggle" data-toggle="sidebar" data-active="true">
            <i class="icon">
               <svg width="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4.25 12.2744L19.25 12.2744" stroke="currentColor" stroke-width="1.5"></path>
                  <path d="M10.2998 18.2988L4.2498 12.2748L10.2998 6.24976" stroke="currentColor" stroke-width="1.5">
                  </path>
               </svg>
            </i>
         </div>
      </div>
      <div class="sidebar-body p-0 data-scrollbar">
         <div class="collapse navbar-collapse pe-3" id="sidebar">
            <ul class="navbar-nav iq-main-menu">
               <li class="nav-item "> <a class="nav-link <?php echo e(Request::path() == 'dashboards' ? 'active' : ''); ?>" href="/dashboards"> <i class="icon" data-feather="command"></i> <span class="item-name">Dashboards</span> </a> </li>
               <li class="nav-item "> <a class="nav-link <?php echo e(Request::segment(2) === 'pengunjung' ? 'active' : null); ?>" href="/dashboards/pengunjung"> <i class="icon" data-feather="bar-chart-2"></i> <span class="item-name">pengunjung</span> </a> </li>
               <li class="nav-item "> <a class="nav-link <?php echo e(Request::segment(2) === 'perhitungan' ? 'active' : null); ?>" href="/dashboards/perhitungan"> <i class="icon" data-feather="search"></i> <span class="item-name">perhitungan</span> </a> </li>
               <li class="nav-item "> <a class="nav-link <?php echo e(Request::segment(2) === 'hasil' ? 'active' : null); ?>" href="/dashboards/hasil"> <i class="icon" data-feather="database"></i> <span class="item-name">hasil</span> </a> </li>
               <?php if(Auth::user()->level ==1): ?>
               <li>
                  <hr class="hr-horizontal">
               </li>
               <li class="nav-item "> <a class="nav-link <?php echo e(Request::segment(2) === 'config' ? 'active' : null); ?>" href="/dashboards/config"> <i class="icon" data-feather="tool"></i> <span class="item-name">Config</span> </a> </li>
               <li class="nav-item "> <a class="nav-link <?php echo e(Request::segment(2) === 'users' ? 'active' : null); ?>" href="/dashboards/users"> <i class="icon" data-feather="users"></i> <span class="item-name">Users</span> </a> </li>
               <?php endif; ?>
               <hr class="hr-horizontal">
               <li class="nav-item "> <a class="nav-link" href="/"> <i class="icon" data-feather="home"></i> <span class="item-name">Homepage</span> </a> </li>
            </ul>
         </div>

      </div>
   </aside>
   <main class="main-content">
      <div class="position-relative">
         <!--Nav Start-->
         <nav class="nav navbar navbar-expand-lg navbar-light iq-navbar border-bottom">
            <div class="container-fluid navbar-inner">
               <a href="<?php echo e(asset('dashboard/')); ?>/dashboard/index.html" class="navbar-brand">
               </a>
               <div class="sidebar-toggle" data-toggle="sidebar" data-active="true">
                  <i class="icon">
                     <svg width="20px" height="20px" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" />
                     </svg>
                  </i>
               </div>
               <h4 class="title">
                  <?php echo $__env->yieldContent('title'); ?>
               </h4>
               <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon">
                     <span class="navbar-toggler-bar bar1 mt-2"></span>
                     <span class="navbar-toggler-bar bar2"></span>
                     <span class="navbar-toggler-bar bar3"></span>
                  </span>
               </button>
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav ms-auto navbar-list mb-2 mb-lg-0 align-items-center">
                     <li class="nav-item dropdown">
                        <a class="nav-link py-0 d-flex align-items-center" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                           <img src="<?php echo e(asset('dashboard/')); ?>/assets/images/avatars/01.png" alt="User-Profile" class="img-fluid avatar avatar-50 avatar-rounded">
                           <div class="caption ms-3 ">
                              <h6 class="mb-0 caption-title"><?php echo e(Auth::user()->name); ?></h6>
                              <p class="mb-0 caption-sub-title"><?php echo e(Auth::user()->email); ?></p>
                           </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                           <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form') .submit();"> <i class="ft-power"></i>Logout </a>
                           <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                              <?php echo csrf_field(); ?>
                           </form>
                        </ul>
                     </li>
                  </ul>
               </div>
            </div>
         </nav> <!--Nav End-->
      </div>
      <div class="container-fluid content-inner pb-0">
         <?php echo $__env->yieldContent('content'); ?>

      </div>
      <footer class="footer">
         <div class="footer-body">
            Copyright ©
            <script>
               document.write(new Date().getFullYear())
            </script>
            </a></li>
            <div class="right-panel">
               Made with
               <span class="text-gray">
                  <svg width="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                     <path fill-rule="evenodd" clip-rule="evenodd" d="M15.85 2.50065C16.481 2.50065 17.111 2.58965 17.71 2.79065C21.401 3.99065 22.731 8.04065 21.62 11.5806C20.99 13.3896 19.96 15.0406 18.611 16.3896C16.68 18.2596 14.561 19.9196 12.28 21.3496L12.03 21.5006L11.77 21.3396C9.48102 19.9196 7.35002 18.2596 5.40102 16.3796C4.06102 15.0306 3.03002 13.3896 2.39002 11.5806C1.26002 8.04065 2.59002 3.99065 6.32102 2.76965C6.61102 2.66965 6.91002 2.59965 7.21002 2.56065H7.33002C7.61102 2.51965 7.89002 2.50065 8.17002 2.50065H8.28002C8.91002 2.51965 9.52002 2.62965 10.111 2.83065H10.17C10.21 2.84965 10.24 2.87065 10.26 2.88965C10.481 2.96065 10.69 3.04065 10.89 3.15065L11.27 3.32065C11.3618 3.36962 11.4649 3.44445 11.554 3.50912C11.6104 3.55009 11.6612 3.58699 11.7 3.61065C11.7163 3.62028 11.7329 3.62996 11.7496 3.63972C11.8354 3.68977 11.9247 3.74191 12 3.79965C13.111 2.95065 14.46 2.49065 15.85 2.50065ZM18.51 9.70065C18.92 9.68965 19.27 9.36065 19.3 8.93965V8.82065C19.33 7.41965 18.481 6.15065 17.19 5.66065C16.78 5.51965 16.33 5.74065 16.18 6.16065C16.04 6.58065 16.26 7.04065 16.68 7.18965C17.321 7.42965 17.75 8.06065 17.75 8.75965V8.79065C17.731 9.01965 17.8 9.24065 17.94 9.41065C18.08 9.58065 18.29 9.67965 18.51 9.70065Z" fill="currentColor"></path>
                  </svg>
            </div>
         </div>
      </footer>
   </main>
   <script>
      feather.replace()
   </script>
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/libs.min.js"></script>
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/charts/widgetcharts.js"></script>
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/fslightbox.js"></script>
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/app.js"></script>
   <script src="<?php echo e(asset('dashboard/')); ?>/assets/js/charts/apexcharts.js"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>