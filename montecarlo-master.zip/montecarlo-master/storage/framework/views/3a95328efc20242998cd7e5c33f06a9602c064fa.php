<?php $__env->startSection('title'); ?>
<?php echo e('perhitungan'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-content">
        <div class="card-body">
            <form action="/dashboards/perhitungan/hitung" class="form form-horizontal" method="GET" id="form">
                <div class="form-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <label class="label-control" for="userinput1">Jenis Data</label>
                                    <br>
                                    <input type="checkbox" id="checkbox" data-group-cls="btn-group-md" checked data-off-cls="btn-light" checked data-on-cls="btn-light" data-on-active-cls="btn-primary" data-off-active-cls="btn-primary">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <label class="label-control" for="bulan">Data Hitung</label>
                                </div>
                                <div class="col-md-12">
                                    <input type="text" id="bulan" name="bulan" class="form-control block" value="<?php echo e(Request()->input('bulan')); ?>" onchange="getbulan()" autocomplete="off">
                                    <input type="text" id="triwulan" name="triwulan" class="form-control block triwulan" value="<?php echo e(Request()->input('triwulan')); ?>" onchange="gettriwulan()" autocomplete="off">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <label class="label-control" for="dataprediksi">Data Prediksi</label>
                                </div>
                                <div class="col-md-12">
                                    <div id="reportrange">
                                        <input type="text" id="dataprediksi" name="dataprediksi" value="<?php echo e(Request()->input('dataprediksi')); ?>" class="form-control" readonly autocomplete="off" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <label class="label-control" for="userinput2">Action</label>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-success"> <i data-feather="search" class="icon"></i> </button>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript">
    const urlParams = new URLSearchParams(window.location.search);
    const bulandata = urlParams.get('bulan'); // "value1"
    const triwulandata = urlParams.get('triwulan'); // "value1"
    if (bulandata == "tidak") {
        $("#checkbox").prop("checked", true);
        document.getElementById('bulan').value = 'tidak';
        document.getElementById('triwulan').value = triwulandata;
        document.getElementById("bulan").style.display = "none";
    } else {
        $("#checkbox").prop("checked", false);
        document.getElementById('triwulan').value = 'tidak';
        document.getElementById('bulan').value = bulandata;
        document.getElementById("triwulan").style.display = "none";
    }
    // document.getElementById('bulan').value = "";
    // document.getElementById('dataprediksi').value = "";
    $("#bulan").datepicker({
        format: "yyyy-mm",
        startView: "months",
        minViewMode: "months",
        startDate: "2000-01",
        endDate: '2100-12',
    }).on("change", function(event) {
        $(".datepicker-dropdown").each(function(index, element) {
            $(element).hide();
        });
    });


    $.fn.datepicker.dates['qtrs'] = {
        days: ["Sunday", "Moonday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        daysShort: ["Sun", "Moon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        daysMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
        months: ["Q1", "Q2", "Q3", "Q4", "", "", "", "", "", "", "", ""],
        monthsShort: ["Jan&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Feb&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mar", "Apr&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;May&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jun", "Jul&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Aug&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sep", "Oct&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nov&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dec", "", "", "", "", "", "", "", ""],
        today: "Today",
        clear: "Clear",
        format: "mm/dd/yyyy",
        titleFormat: "MM yyyy",
        weekStart: 0
    };

    $('#triwulan').datepicker({
        format: "MM yyyy",
        minViewMode: 1,
        autoclose: true,
        language: "qtrs",
        forceParse: false
    })




    $(':checkbox').checkboxpicker({
        onLabel: "3 Bulan",
        offLabel: "1 Bulan"
    });

    $("#checkbox").on('change', function() {
        if ($(this).is(':checked')) {
            switchStatus = $(this).is(':checked');
            // console.log("3 Bulan");
            document.getElementById("triwulan").style.display = "block";
            document.getElementById('triwulan').value = "";
            document.getElementById("bulan").style.display = "none";
            document.getElementById('bulan').value = "tidak";
            document.getElementById('dataprediksi').value = "";
        } else {
            switchStatus = $(this).is(':checked');
            // console.log("1 Bulan");
            document.getElementById("bulan").style.display = "block";
            document.getElementById('bulan').value = "";
            document.getElementById("triwulan").style.display = "none";
            document.getElementById('triwulan').value = "tidak";
            document.getElementById('dataprediksi').value = "";
        }
    });


    function gettriwulan() {
        var datatriwulan = document.getElementById('triwulan').value;
        var [quarterdepan, triwulandepan] = datatriwulan.split(" ");

        if (quarterdepan === 'Q1') {
            quarterdepan = 'Q2';
            triwulandepan = triwulandepan;
            var datatriwulandepan = 'Q2 ' + triwulandepan;
        } else if (quarterdepan === 'Q2') {
            quarterdepan = 'Q3';
            triwulandepan = triwulandepan;
            var datatriwulandepan = 'Q3 ' + triwulandepan;
        } else if (quarterdepan === 'Q3') {
            quarterdepan = 'Q4';
            triwulandepan = triwulandepan;
            var datatriwulandepan = 'Q4 ' + triwulandepan;
        } else if (quarterdepan === 'Q4') {
            quarterdepan = 'Q1';
            triwulandepan = parseInt(triwulandepan) + 1;
            var datatriwulandepan = 'Q1 ' + triwulandepan;
        }
        document.getElementById('dataprediksi').value = datatriwulandepan;
    }


    function getbulan() {
        var dataprediksi = moment($('#bulan').val()).add(1, 'months').format("YYYY-MM");
        document.getElementById('dataprediksi').value = dataprediksi;
    }
</script>


<div class="card-body">

    <?php if( request()->triwulan == 'tidak'): ?>
    <?php if( request()->get('bulan') ): ?>
    <div class="bulan">
        <?php if(isset($pengunjung)): ?>

        <div class="form-body" id="div1">
            <div id=" ">
                <table class="table table-striped table-bordered " role="grid">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Pengunjung</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for($i = 1; $i <= $jumlahhari; $i++): ?> <tr>
                            <td><?php echo e($i); ?> </td>
                            <td><?php echo $datapengunjung[$i]; ?></td>
                            </tr>
                            <?php endfor; ?>
                            <tr>
                                <td>Total</td>
                                <td><?php echo e($totalpengunjung); ?></td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>

        <div class="form-body" id="div2">
            <h4 class="form-section mb-2 mt-4"><i class="ft-filter"></i> Frekuensi</h4>
            <hr class="mb-2" />
            <table class="table table-striped table-bordered mt-2" role="grid">
                <thead>
                    <tr>
                        <th width="50%">Frekuensi </th>
                        <th>Jumlah Frekuensi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $looping; $i++): ?> <tr>
                        <td><?php echo e($allkeys[$i]); ?></td>
                        <td><?php echo e($allvalues[$i]); ?></td>
                        </tr>
                        <?php endfor; ?>
                        <tr>
                            <td>Total Frequency</td>
                            <td><?php echo e($jumlah); ?></td>
                        </tr>
                </tbody>
            </table>

        </div>

        <div class="form-body" id="div3">
            <h4 class="form-section mt-5 mb-2"><i class=" ft-grid"></i> Distribution Data</h4>
            <hr class="mb-2" />
            <div id="tb_product_wrapper">
                <table class="table table-striped table-bordered" id="tb_product" role="grid">
                    <thead>
                        <tr>
                            <th>Frequency</th>
                            <th>DPF</th>
                            <th>DPK</th>
                            <th>Interval</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php for($i = 0; $i < $looping; $i++): ?> <tr>
                            <td><?php echo e($allkeys[$i]); ?></td>
                            <td><?php echo e(round($probability[$i],3)); ?></td>
                            <td><?php echo e(round($cumulative[$i],3)); ?></td>
                            <td><?php echo e($i==0?"0.001":round($intervalbawah[$i],3)); ?>-<?php echo e(round($intervalatas[$i],3)); ?></td>
                            </tr>
                            <?php endfor; ?>
                    </tbody>
                </table>

            </div>
        </div>

        <div class="form-body" id="div4">
            <h4 class="form-section mt-5 mb-2"><i class="ft-cpu"></i> Prediksi Pengunjung</h4>
            <hr class="mb-2" />
            <div class="table-responsive">
                <table class="table table-striped table-bordered"  >
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Bilangan Acak</th>
                            <th>Prediksi Pengunjung</th>
                            <th>Total Pengunjung Asli</th>
                            <th>APE</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php for($i = 1; $i <= $jumlahharibulandepan; $i++): ?> <tr>
                            <td><?php echo e($i); ?> </td>
                            <td><?php echo e($randomnumber[$i]); ?></td>
                            <td>
                                <?php if(isset($hasilprediksi[$i])): ?>
                                <?php echo e($hasilprediksi[$i]); ?>

                                <?php else: ?>
                                0
                                <?php endif; ?>
                            </td>
                            <?php if(!isset($dataaslibelumada)): ?>
                            <td><?php echo e(isset($dataasli[$i])?$dataasli[$i]:0); ?> </td>
                            <td><?php echo e(isset($ape[$i])?round($ape[$i],3):0); ?> </td>
                            <?php else: ?>
                            <td>0</td>
                            <td>0</td>
                            <?php endif; ?>
                            </tr>
                            <?php endfor; ?>
                            <?php if(!isset($dataaslibelumada)): ?>
                            <th></th>
                            <th></th>
                            <th>Total: <?php echo e($totalprediksi); ?> </th>
                            <th>Total: <?php echo e($totaldataasli); ?> </th>
                            <th>MAPE: <?php echo e(round($mape,4)); ?>% </th>
                            <?php else: ?>
                            <th></th>
                            <th></th>
                            <th>Total: <?php echo e($totalprediksi); ?> </th>
                            <th>Total: 0</th>
                            <th>MAPE: 0</th>
                            <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>


        <?php else: ?>

        <div class="alert alert-icon-left bg-primary alert-dismissible " role="alert">
            <strong>Perhatian ! pengunjung data tidak ditemukan. </strong> buat data pengunjung dulu <br>
        </div>

        <?php endif; ?>
    </div>
    <div style="display:flex;justify-content:center " class="mt-4 mb-4">
        <form action="/dashboards/perhitungan/print" class="form form-horizontal" method="GET" style="display: flex;  justify-content: center;  align-items: center;">
            <input type="hidden" value='bulan' name="dataprediksi">
            <input type="hidden" value="<?php echo e(isset($pengunjung) ? json_encode($pengunjung) : ''); ?>" name="pengunjung">
            <input type="hidden" value="<?php echo e(isset($jumlahharibulandepan) ? json_encode($jumlahharibulandepan) : 0); ?>" name="jumlahharibulandepan">
            <input type="hidden" value="<?php echo e(isset($hasilprediksi) ? json_encode($hasilprediksi) :''); ?>" name="hasilprediksi">
            <input type="hidden" value="<?php echo e(isset($dataasli) ? json_encode($dataasli) :''); ?>" name="dataasli">
            <input type="hidden" value="<?php echo e(isset($ape) ? json_encode($ape) : ''); ?>" name="ape">
            <input type="hidden" value="<?php echo e(isset($totalprediksi) ? json_encode($totalprediksi) : ''); ?>" name="totalprediksi">
            <input type="hidden" value="<?php echo e(isset($totaldataasli) ? json_encode($totaldataasli) : ''); ?>" name="totaldataasli">
            <input type="hidden" value="<?php echo e(isset($mape) ? $mape : ''); ?>" name="mape">
            <input type="submit" class="btn btn-secondary" value="Print">
        </form>
    </div>
    <?php else: ?>
    <div class="alert alert-icon-left bg-light text-dark alert-dismissible " role="alert">
        <strong>Perhatian! </strong> harap isi formulir dengan benar untuk melakukan perhitungan <br>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <?php if( request()->get('triwulan') ): ?>
    <div class="triwulan">
        <?php if(isset($pengunjung)): ?>

        <div class="form-body" id="div1">
            <div id=" ">
                <table class="table table-striped table-bordered " role="grid">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Pengunjung</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for($i = 1; $i <= 3; $i++): ?> <tr>
                            <td><?php echo e($i); ?> </td>
                            <td><?php echo $datapengunjung[$i]; ?></td>
                            </tr>
                            <?php endfor; ?>
                            <tr>
                                <td>Total</td>
                                <td><?php echo e($totalpengunjung); ?></td>
                            </tr>
                    </tbody>
                </table>

            </div>
        </div>

        <div class="form-body" id="div2">
            <h4 class="form-section mb-2 mt-4"><i class="ft-filter"></i> Frekuensi</h4>
            <hr class="mb-2" />
            <table class="table table-striped table-bordered mt-2" role="grid">
                <thead>
                    <tr>
                        <th width="50%">Frekuensi </th>
                        <th>Jumlah Frekuensi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $looping; $i++): ?> <tr>
                        <td><?php echo e($allkeys[$i]); ?></td>
                        <td><?php echo e($allvalues[$i]); ?></td>
                        </tr>
                        <?php endfor; ?>
                        <tr>
                            <td>Total Frequency</td>
                            <td><?php echo e($jumlah); ?></td>
                        </tr>
                </tbody>
            </table>

        </div>

        <div class="form-body" id="div3">
            <h4 class="form-section mt-5 mb-2"><i class=" ft-grid"></i> Distribution Data</h4>
            <hr class="mb-2" />
            <div id="tb_product_wrapper">
                <table class="table table-striped table-bordered" id="tb_product" role="grid">
                    <thead>
                        <tr>
                            <th>Frequency</th>
                            <th>DPF</th>
                            <th>DPK</th>
                            <th>Interval</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php for($i = 0; $i < $looping; $i++): ?> <tr>
                            <td><?php echo e($allkeys[$i]); ?></td>
                            <td><?php echo e(round($probability[$i],3)); ?></td>
                            <td><?php echo e(round($cumulative[$i],3)); ?></td>
                            <td><?php echo e($i==0?"0.001":round($intervalbawah[$i],3)); ?>-<?php echo e(round($intervalatas[$i],3)); ?></td>
                            </tr>
                            <?php endfor; ?>
                    </tbody>
                </table>

            </div>
        </div>

        <div class="form-body" id="div4">
            <h4 class="form-section mt-5 mb-2"><i class="ft-cpu"></i> Prediksi Permintaan</h4>
            <hr class="mb-2" />
            <div id="tb_product_wrapper">
                <table class="table table-striped table-bordered" id="tb_product" role="grid">
                    <thead>
                        <tr>
                            <th>Bulan Pada <?php echo e(request()->triwulan); ?></th>
                            <th>Bilangan Acak</th>
                            <th>Prediksi Permintaan</th>
                            <th>Total Permintaan Asli</th>
                            <th>APE</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php for($i = 1; $i <= 3; $i++): ?> <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($randomnumber[$i]); ?></td>
                            <td>
                                <?php if(isset($hasilprediksi[$i])): ?>
                                <?php echo e($hasilprediksi[$i]); ?>

                                <?php else: ?>
                                0
                                <?php endif; ?>
                            </td>
                            <?php if(!isset($dataaslibelumada)): ?>
                            <td><?php echo e(isset($dataasli[$i])?$dataasli[$i]:0); ?> </td>
                            <td><?php echo e(isset($ape[$i])?$ape[$i]:0); ?> </td>
                            <?php else: ?>
                            <td>0</td>
                            <td>0</td>
                            <?php endif; ?></tr>
                            <?php endfor; ?>
                            <?php if(!isset($dataaslibelumada)): ?>
                            <th></th>
                            <th></th>
                            <th>Total: <?php echo e($totalprediksi); ?> </th>
                            <th>Total: <?php echo e($totaldataasli); ?> </th>
                            <th>MAPE: <?php echo e($mape); ?>% </th>
                            <?php else: ?>
                            <th></th>
                            <th></th>
                            <th>Total: <?php echo e($totalprediksi); ?></th>
                            <th>Total: 0</th>
                            <th>MAPE: 0</th>
                            <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>


        <?php else: ?>

        <div class="alert alert-icon-left bg-primary alert-dismissible " role="alert">
            <strong>Perhatian ! pengunjung data tidak ditemukan. </strong> buat data pengunjung dulu <br>
        </div>

        <?php endif; ?>
    </div>
    <div style="display:flex;justify-content:center " class="mt-4 mb-4">
        <form action="/dashboards/perhitungan/print" class="form form-horizontal" method="GET" style="display: flex;  justify-content: center;  align-items: center;">
            <input type="hidden" value='triwulan' name="dataprediksi">
            <input type="hidden" value='<?php echo e(request()->triwulan); ?>' name="triwulan">
            <input type="hidden" value="<?php echo e(isset($pengunjung) ? json_encode($pengunjung) : ''); ?>" name="pengunjung">
            <input type="hidden" value="<?php echo e(isset($jumlahharibulandepan) ? json_encode($jumlahharibulandepan) : 0); ?>" name="jumlahharibulandepan">
            <input type="hidden" value="<?php echo e(isset($hasilprediksi) ? json_encode($hasilprediksi) :''); ?>" name="hasilprediksi">
            <input type="hidden" value="<?php echo e(isset($dataasli) ? json_encode($dataasli) :''); ?>" name="dataasli">
            <input type="hidden" value="<?php echo e(isset($ape) ? json_encode($ape) : ''); ?>" name="ape">
            <input type="hidden" value="<?php echo e(isset($totalprediksi) ? json_encode($totalprediksi) : ''); ?>" name="totalprediksi">
            <input type="hidden" value="<?php echo e(isset($totaldataasli) ? json_encode($totaldataasli) : ''); ?>" name="totaldataasli">
            <input type="hidden" value="<?php echo e(isset($mape) ? $mape : ''); ?>" name="mape">
            <input type="submit" class="btn btn-secondary" value="Print">
        </form>
    </div>
    <?php else: ?>
    <div class="alert alert-icon-left bg-light text-dark alert-dismissible " role="alert">
        <strong>Perhatian! </strong> harap isi formulir dengan benar untuk melakukan perhitungan <br>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/perhitungan/index.blade.php ENDPATH**/ ?>