<?php $__env->startSection('title'); ?>
<?php echo e('Pengunjung View'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="card-content collpase show">
            <div class="card-body">
                <div class="form-body table-responsive">
                    <table class="table "  >
                        <tbody>
                            <?php
                            $data = explode('-', $pengunjung->bulan);
                            $datatahun = $data[0];
                            $databulan = $data[1];
                            if ($databulan == '01' || $databulan == '03' || $databulan == '05' || $databulan == '07' || $databulan == '08' || $databulan == '10' || $databulan == '12') {
                                $jumlahhari = 31;
                            } elseif ($databulan == '04' || $databulan == '06' || $databulan == '09' || $databulan == '11') {
                                $jumlahhari = 30;
                            } else {
                                if ($datatahun % 4 == 0) {
                                    $jumlahhari = 28;
                                } elseif ($datatahun % 4 != 0) {
                                    $jumlahhari = 29;
                                }
                            }
                            ?>
                            <tr>
                                <td><b>
                                        <h1> Bulan
                                    </b></h1>
                                </td>
                                <td><b>
                                        <h1> <?php echo e($pengunjung->bulan); ?>

                                    </b></h1>
                                </td>
                            </tr> 
                            <?php for($i = 1; $i <= $jumlahhari; $i++): ?> 
                            <tr>
                                <td> Tanggal <?php echo e($i); ?>

                                <td><?php echo $pengunjung->{'t' . $i};   ?> </td>
                            </tr>
                                <?php endfor; ?>
                                
                            <tr>
                                <td><b>
                                        <h1> Jumlah Pengunjung
                                    </b></h1>
                                </td>
                                <td><b>
                                        <h1><?php echo e($jumlah); ?>

                                    </b></h1>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
                <div class="d-flex justify-content-center p-3">
                    <a class="btn btn-secondary ml-1 mt-2" href="/dashboards/pengunjung"><i data-feather="arrow-left" class="icon"></i>Back </a>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/pengunjung/view.blade.php ENDPATH**/ ?>