<?php $__env->startSection('title'); ?>
<?php echo e('hasil'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-content">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table dataTable">
          <thead>
            <tr role="row">
              <th>Id</th>
              <th>Pengunjung_id</th>
              <th>Data Prediksi</th>
              <th>Mape</th>
              <th>Timestamp</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no =>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr role="row" class="odd">
              <td><?php echo e($no+1); ?></td>
              <td><?php echo e($row -> pengunjung_id); ?></td>
              <td><?php echo e($row -> data_prediksi); ?></td>
              <?php 
              $data = json_decode($row -> mape, true);
              ?>
              <td><?php echo e($data['mape']); ?>%</td>
              <td><?php echo e($row -> updated_at -> diffForHumans()); ?></td>
              <td>
                <form action="<?php echo e(route('hasil.destroy',$row->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <a class="btn btn-info btn-sm" href="<?php echo e(URL::to('dashboards/hasil/'.$row -> id)); ?>"><i data-feather="eye" class="icon"></i></a>
                  <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm"><i data-feather="trash" class="icon"></i></button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

      </div>
    </div>
  </div>
</div>
<script>
 feather.replace()
    $('.dataTable').dataTable({
        "pageLength": 25
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/hasil/index.blade.php ENDPATH**/ ?>