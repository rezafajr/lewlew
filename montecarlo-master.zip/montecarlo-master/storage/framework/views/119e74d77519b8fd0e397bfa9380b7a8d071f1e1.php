<?php $__env->startSection('title'); ?>
<?php echo e('Pengunjung'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="card">
    <div class="card-content">
        <div class="card-body">

            <div class="d-flex justify-content-center p-3">
                <a class="btn btn-success ml-1" href="/dashboards/pengunjung/create"><i data-feather="plus" class="icon"></i> Add</a>
            </div>
            <div id="tb_product_wrapper" class="dataTables_wrapper dt-bootstrap4">
                <table class="table table-striped table-bordered file-export dataTable " id="tb_product" role="grid">
                    <thead>
                        <tr role="row">
                            <th style="width: 5%;">No</th>
                            <th style="width: 10%;">Bulan</th>
                            <th style="width: 5%;">Pengunjung</th>
                            <th style="width: 25%;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pengunjung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr role="row" class="odd">
                            <td class="sorting_1"><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->bulan); ?></td>
                            <?php
                            $count = 0;
                            $data = explode('-', $row->bulan);
                            $datatahun = $data[0];
                            $databulan = $data[1];
                            if ($databulan == '01' || $databulan == '03' || $databulan == '05' || $databulan == '07' || $databulan == '08' || $databulan == '10' || $databulan == '12') {
                                $jumlahhari = 31;
                            } elseif ($databulan == '04' || $databulan == '06' || $databulan == '09' || $databulan == '11') {
                                $jumlahhari = 30;
                            } else {
                                if ($datatahun % 4 == 0) {
                                    $jumlahhari = 28;
                                } elseif ($datatahun % 4 != 0) {
                                    $jumlahhari = 29;
                                }
                            }
                            $totalpenjulan = 0;
                            for ($i = 1; $i <= $jumlahhari; $i++) {
                                $totalpenjulan += $row->{'t' . $i};
                            }
                            ?>

                            <?php for($i = 1; $i <= $jumlahhari; $i++): ?> <?php if(isset($row->{'t' . $i})): ?>
                                <?php $count += 1; ?>
                                <?php endif; ?>
                                <?php endfor; ?>
                                <td><?php echo e($totalpenjulan); ?>


                                    <?php if($count - $jumlahhari != 0): ?>
                                    <span class="badge badge-default bg-warning">Data Kurang
                                        <?php echo e($count - $jumlahhari); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('pengunjung.destroy',$row->id)); ?>" method="POST">
                                        <a class="btn btn-info btn-sm" href="<?php echo e(URL::to('dashboards/pengunjung/'.$row -> id)); ?>"><i data-feather="eye" class="icon"></i></a>
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(URL::to('dashboards/pengunjung/'.$row -> id.'/edit/')); ?>"><i data-feather="edit" class="icon"></i></a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm"><i data-feather="trash" class="icon"></i></button>
                                    </form>
                                </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>

        </div>
    </div>
</div>
<script>
    feather.replace()
    $('.dataTable').dataTable({
        "pageLength": 50
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/pengunjung/index.blade.php ENDPATH**/ ?>