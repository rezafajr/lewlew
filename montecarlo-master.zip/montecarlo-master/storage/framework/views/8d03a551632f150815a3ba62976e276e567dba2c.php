<!DOCTYPE html>
<html>

<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .laporan-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .laporan-header h1 {
            font-size: 24px;
        }

        .laporan-details {
            margin-bottom: 20px;
        }

        .laporan-details p {
            margin: 5px;
        }

        .laporan-table {
            width: 100%;
            border-collapse: collapse;
        }

        .laporan-table th,
        .laporan-table td {
            border: 1px solid #000;
            padding: 8px;
        }
    </style>
</head>

<body>
    <div class="laporan-container">
        <div class="laporan-header">
            <h1>LAPORAN</h1>
            <p>Tanggal: <?php echo date('j F  Y'); ?></p>
        </div>
        <?php if($data['dataprediksi']=='bulan'): ?>
            <div class="laporan-details">
                <?php
                    $pengunjung = json_decode($data['pengunjung']);
                ?>
                <p>Jenis Data Prediksi: <b><?php echo e($data['dataprediksi']); ?></b> </p>
                <p>Data Perhitungan: <b><?php echo e($pengunjung->bulan); ?></b></p>

            </div>
            <div class="form-body" id="div4">
                <h4 class="form-section mt-5 mb-2"><i class="ft-cpu"></i> Prediksi Pengunjung</h4>
                <div id="tb_product_wrapper">
                    <table class="laporan-table">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Prediksi Pengunjung</th>
                                <th>Total Pengunjung Asli</th>
                                <th>APE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $hasilprediksi = json_decode($data['hasilprediksi']);
                            $dataasli = json_decode($data['dataasli']); // Corrected variable name
                            $ape = json_decode($data['ape']);
                            ?>

                            <?php for($i = 1; $i <= $data['jumlahharibulandepan']; $i++): ?> <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e(isset($hasilprediksi->$i) ? $hasilprediksi->$i : "0"); ?> </td>
                                <?php if(!isset($dataaslibelumada)): ?>
                                <td><?php echo e(isset($dataasli->$i) ? $dataasli->$i : 0); ?>

                                <td><?php echo e(isset($ape->$i) ? round($ape->$i,3) : 0); ?>

                                    <?php else: ?>
                                <td>0</td>
                                <td>0</td>
                                <?php endif; ?>
                                </tr>
                                <?php endfor; ?>
                                <th></th>
                            <th>Total: <?php echo e($data['totalprediksi']); ?> </th>
                            <?php if( !isset($dataaslibelumada)): ?>
                            <th>Total: <?php echo e($data['totaldataasli']); ?> </th>
                            <th>MAPE: <?php echo e(round($data['mape'],4)); ?>% </th>
                            <?php else: ?>
                            <th>Total: 0</th>
                            <th>MAPE: 0</th>
                            <?php endif; ?>
                        </tbody>
                    </table>


                </div>
            </div> 
        <?php else: ?>
        <div class="laporan-details"> 
                <p>Jenis Data Prediksi: <b><?php echo e($data['dataprediksi']); ?></b> </p>
                <p>Data Perhitungan: <b><?php echo e($data['triwulan']); ?></b></p>
            </div>
           
        <div class="form-body" id="div4">
            <div id="tb_product_wrapper">
            <table class="laporan-table">
                    <thead>
                        <tr>
                            <th>Bulan Pada <?php echo e($data['triwulan']); ?></th>
                            <th>Prediksi Permintaan</th>
                            <th>Total Permintaan Asli</th>
                            <th>APE</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php
                            $hasilprediksi = json_decode($data['hasilprediksi']);
                            $dataasli = json_decode($data['dataasli']); // Corrected variable name
                            $ape = json_decode($data['ape']);
                            ?>

                            <?php for($i = 1; $i <= 3; $i++): ?> <tr> 
                            <td><?php echo e($i); ?></td>

                                <td><?php echo e(isset($hasilprediksi->$i) ? $hasilprediksi->$i : "0"); ?> </td>
                                <?php if(!isset($dataaslibelumada)): ?>
                                <td><?php echo e(isset($dataasli->$i) ? $dataasli->$i : "0"); ?>

                                <td><?php echo e(isset($ape->$i) ? $ape->$i : "0"); ?>

                                <?php endif; ?>
                                </tr>
                                <?php endfor; ?>  
                            <th></th>
                            <th>Total: <?php echo e($data['totalprediksi']); ?> </th>
                            <?php if( !isset($dataaslibelumada)): ?>
                            <th>Total: <?php echo e($data['totaldataasli']); ?> </th>
                            <th>MAPE: <?php echo e($data['mape']); ?>% </th>
                            <?php else: ?>
                            <th>Total: 0</th>
                            <th>MAPE: 0</th>
                            <?php endif; ?>
                        </tbody>
                </table>

            </div>
        </div>
        <?php endif; ?>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\montecarlo-master\resources\views/dashboards/perhitungan/print.blade.php ENDPATH**/ ?>