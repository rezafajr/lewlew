<?php

namespace App\Http\Controllers;


use App\Models\Pengunjung;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PengunjungController extends Controller
{
    public function index()
    {
        $pengunjung = pengunjung::get();
        return view('dashboards.pengunjung.index', compact('pengunjung'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboards.pengunjung.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $duplikat = pengunjung::where('bulan', $request->bulan)->first();
        if ($duplikat != NULL) {
            $pengunjung = pengunjung::get();
            return view('dashboards.pengunjung.create', compact('pengunjung', 'duplikat'));
        } else {
            $this->validate($request, [
                'bulan' => 'required|date',
            ]);
            $pengunjung = new pengunjung();
            $pengunjung->bulan = $request->bulan;
            $data = explode('-', $request->bulan);
            $datatahun = $data[0];
            $databulan   = $data[1];
            if ($databulan == '01' || $databulan == '03' || $databulan == '05' || $databulan == '07' || $databulan == '08' || $databulan == '10' || $databulan == '12') {
                $jumlahhari = 31;
            } else if ($databulan == '04' || $databulan == '06' || $databulan == '09' || $databulan == '11') {
                $jumlahhari = 30;
            } else {
                if ($datatahun % 4 == 0) {
                    $jumlahhari = 28;
                } else if ($datatahun % 4 != 0) {
                    $jumlahhari = 29;
                }
            }

            for ($i = 1; $i <= $jumlahhari; $i++) {
                $pengunjung->{'t' . $i} =  $request->{'t' . $i};
            }
            $pengunjung->save();
            toast('pengunjung added successfully', 'success');
            $pengunjung = pengunjung::get();
            return view('dashboards.pengunjung.index', compact('pengunjung'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $pengunjung = pengunjung::findorfail($id);
        $jumlah = 0;
        $data = explode('-', $pengunjung->bulan);
        $datatahun = $data[0];
        $databulan   = $data[1];
        if ($databulan == '01' || $databulan == '03' || $databulan == '05' || $databulan == '07' || $databulan == '08' || $databulan == '10' || $databulan == '12') {
            $jumlahhari = 31;
        } else if ($databulan == '04' || $databulan == '06' || $databulan == '09' || $databulan == '11') {
            $jumlahhari = 30;
        } else {
            if ($datatahun % 4 == 0) {
                $jumlahhari = 28;
            } else if ($datatahun % 4 != 0) {
                $jumlahhari = 29;
            }
        }
        for ($loop = 1; $loop <= $jumlahhari; $loop++) {
            $jumlah += $pengunjung['t' . $loop];
        }
        return view('dashboards.pengunjung.view', compact('pengunjung', 'jumlah'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pengunjung = pengunjung::findorfail($id);

        $data = explode('-', $pengunjung->bulan);
        $datatahun = $data[0];
        $databulan   = $data[1];
        if ($databulan == '01' || $databulan == '03' || $databulan == '05' || $databulan == '07' || $databulan == '08' || $databulan == '10' || $databulan == '12') {
            $jumlahhari = 31;
        } else if ($databulan == '04' || $databulan == '06' || $databulan == '09' || $databulan == '11') {
            $jumlahhari = 30;
        } else {
            if ($datatahun % 4 == 0) {
                $jumlahhari = 28;
            } else if ($datatahun % 4 != 0) {
                $jumlahhari = 29;
            }
        }
        return view('dashboards.pengunjung.edit', compact('pengunjung', 'jumlahhari'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $pengunjung = pengunjung::findorfail($id);

        $pengunjung->bulan = $request->bulan;
        for ($i = 1; $i <= 31; $i++) {
            $pengunjung->{'t' . $i} =  $request->{'t' . $i};
        }
        $pengunjung->save();
        toast('Pengunjung changed successfully', 'success');
        return redirect('/dashboards/pengunjung');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pengunjung = pengunjung::where('id', $id)->get();
        $pengunjung->each->delete();
        toast('Pengunjung deleted successfully', 'success');
        return redirect('/dashboards/pengunjung');
    }
}
