<?php

namespace App\Http\Controllers;

use App\Models\Config;
use App\Models\Pengunjung;
use App\Models\Hasil;
use Illuminate\Http\Request;
use PDF;

class PerhitunganController extends Controller
{

    public function index()
    {
        $pengunjung = pengunjung::get();
        return view('dashboards.perhitungan.index', compact('pengunjung'));
    }
    public function hitung(Request $request)
    {
        $pengunjung = pengunjung::get();
        // dd($request->all());
        if ($request->bulan != "tidak") {
            if (!empty($request->bulan)) {
                $dataprediksi = $request->bulan;
                $data = explode('-', $dataprediksi);
                $tahun = $data[0]; //2023
                $bulan = $data[1];
                if ($bulan == '01' || $bulan == '03' || $bulan == '05' || $bulan == '07' || $bulan == '08' || $bulan == '10' || $bulan == '12') {
                    $jumlahhari = 31;
                } else if ($bulan == '04' || $bulan == '06' || $bulan == '09' || $bulan == '11') {
                    $jumlahhari = 30;
                } else if ($bulan == '02') {
                    if ($tahun % 4 == 0) {
                        $jumlahhari = 29;
                    } else if ($tahun % 4 != 0) {
                        $jumlahhari = 28;
                    }
                } else {
                    $bulanberikutnya = "invalid data bulan";
                }
                $pengunjung = pengunjung::where('bulan', $dataprediksi)->first();
                // dd($pengunjung);
                if ($pengunjung == null) {
                    // dd("pengunjung tidak ada");
                    return view('dashboards.perhitungan.index');
                }
                $totalpengunjung = 0;
                $datapengunjung = [];
                if ($pengunjung) {
                    for ($i = 1; $i <= $jumlahhari; $i++) {
                        $datapengunjung[$i] = $pengunjung['t' . $i];
                        $totalpengunjung += $pengunjung['t' . $i];
                    }
                }

                if ($bulan == '12' || $bulan == '02' || $bulan == '04' || $bulan == '06' || $bulan == '07' || $bulan == '09' || $bulan == '11') {
                    $jumlahharibulandepan = 31;
                } else if ($bulan == '03' || $bulan == '05' || $bulan == '08' || $bulan == '10') {
                    $jumlahharibulandepan = 30;
                } else if ($bulan == '01') {
                    if (($tahun % 4 == 0 && $tahun % 100 != 0) || ($tahun % 400 == 0)) {
                        $jumlahharibulandepan = 29;
                    } else if ($tahun % 4 != 0) {
                        $jumlahharibulandepan = 28;
                    }
                } else {
                    $bulanberikutnya = "invalid data bulan";
                }


                function frequency(array $values): array
                {
                    $frequencies = array();
                    foreach ($values as $value) {
                        if (!isset($frequencies[$value])) {
                            $frequencies[$value] = 1;
                        } else {
                            $frequencies[$value]++;
                        }
                    }
                    return $frequencies;
                }
                $hasilurut = frequency($datapengunjung);
                ksort($hasilurut);
                // dd($hasilurut);
                $allkeys = array_keys($hasilurut);
                $allvalues = array_values($hasilurut);
                $jumlah = array_sum(array_column($hasilurut, null));
                $looping = sizeof($allkeys);
                $permintaan = $allkeys;
                $frekuensi = $allvalues;
                $probability = [];
                $cumulative = [];
                for ($i = 0; $i < $looping; $i++) {
                    $probability[$i] =  $frekuensi[$i] / $jumlah;
                    if ($i === 0) {
                        $cumulative[$i] = $probability[$i];
                    } else {
                        $cumulative[$i] = $probability[$i] + $cumulative[$i - 1];
                    }
                }
                // dd($cumulative);
                $length = 0;
                for ($i = 0; $i < $looping; $i++) {
                    if ($length < strlen($cumulative[$i])) {
                        $length = strlen($cumulative[$i]) - 2;
                    }
                }
                $intervalawal = 0.001;
                $intervalbawah[0] = $intervalawal;
                $intervalatas[0] = $cumulative[0];
                for ($i = 1; $i < $looping; $i++) {
                    $intervalbawah[$i] =  $intervalatas[$i - 1] + $intervalawal;
                    $intervalatas[$i] =  $cumulative[$i];
                }

                // dd($intervalbawah,$intervalatas);
                $config = Config::first();
                $a = $config->a;
                $c = $config->c;
                $m = $config->m;
                $z0 = $config->z0;
                //  dd($config)
                $temprandom = [];
                $temprandom[0] = $z0;

                // $asd =0;
                for ($i = 1; $i <= $jumlahharibulandepan; $i++) {
                    $temprandom[$i] = ($a * $temprandom[$i - 1] + $c) % $m;
                    $randomnumber[$i] = round($temprandom[$i] / $m, 5);
                    // $asd += $randomnumber[$i];
                }
                // dd($asd);
                // dd($randomnumber);

                $hasilprediksi = [];
                for ($i = 1; $i <= $jumlahharibulandepan; $i++) {
                    // for ($i = 1; $i <= 29; $i++) {
                    for ($j = 0; $j < $looping - 1; $j++) {
                        // echo ($randomnumber[$i]);
                        if ($randomnumber[$i] >= $intervalbawah[$j] && $randomnumber[$i] <= $intervalatas[$j]) {
                            $hasilprediksi[$i] = $allkeys[$j];
                            // dd( $hasilprediksi[$i]);
                        } elseif ($randomnumber[$i] >= $intervalatas[$j]) {
                            $hasilprediksi[$i] = $allkeys[$j + 1];
                        }
                    }
                }
                // dd($hasilprediksi);
                $totalprediksi = array_sum(array_column($hasilprediksi, null)); //mengambil total value
                // dd($totalprediksi);

                //cek next month apakah ada
                $bulandepan = Date("Y-m", strtotime($dataprediksi . " +1 month"));
                // dd($bulandepan);
                $databulandepan = $bulandepan;
                $cekdataasli = Pengunjung::select('*')->where('bulan', '=', $bulandepan)->first();
                // dd($cekdataasli);
                $dataasli = [];
                $ape = [];
                $totalape = 0;
                if ($cekdataasli != null) {
                    $totaldataasli = 0;
                    for ($i = 1; $i <= $jumlahharibulandepan; $i++) {
                        $dataasli[$i] =  $cekdataasli->{'t' . $i};
                        $ape[$i] = $dataasli[$i] == 0 ?: (($cekdataasli->{'t' . $i} - $hasilprediksi[$i]) /  $cekdataasli->{'t' . $i}) * 100;
                        $totalape +=  $ape[$i];
                        $totaldataasli += $cekdataasli->{'t' . $i};
                    }
                    $mape = $totalape / $jumlahharibulandepan;


                    $hasil = new hasil();
                    $hasil->pengunjung_id = $pengunjung->id;
                    $hasil->data_prediksi = $dataprediksi;
                    $data = [ 
                        'dataprediksi' => $dataprediksi,
                        'hasilprediksi' => $hasilprediksi,
                        'totalprediksi' => $totalprediksi,
                        'dataasli' => $dataasli,
                        'totaldataasli' => $totaldataasli,
                        'ape' => $ape,
                        'mape' => $mape,
                    ];
                    $hasil->mape = json_encode($data);
                    $hasil->save();
                    // dd($pengunjung->id);
                    // dd($hasil);
                    // dd($ape,$totalape,$jumlahharibulandepan,$mape);
                    return view('dashboards.perhitungan.index', compact('jumlahhari', 'datapengunjung', 'totalpengunjung', 'pengunjung', 'allkeys', 'allvalues', 'jumlah', 'looping', 'probability', 'cumulative', 'intervalbawah', 'intervalatas', 'jumlahharibulandepan', 'randomnumber', 'hasilprediksi', 'totalprediksi', 'dataasli', 'cekdataasli', 'databulandepan', 'ape', 'mape', 'totaldataasli'));
                } else { //jika tida ada mape
                    $dataaslibelumada = true;
                    return view('dashboards.perhitungan.index', compact('jumlahhari', 'datapengunjung', 'totalpengunjung', 'pengunjung', 'allkeys', 'allvalues', 'jumlah', 'looping', 'probability', 'cumulative', 'intervalbawah', 'intervalatas', 'jumlahharibulandepan', 'randomnumber', 'hasilprediksi', 'totalprediksi', 'dataasli', 'cekdataasli', 'databulandepan', 'dataaslibelumada'));
                }
            } else { //jika parameter tidak valid
                return view('dashboards.perhitungan.index', compact('pengunjung'));
            }
        } else {
            // dd("ini request triwulan");
            if (!empty($request->triwulan)) {
                $dataprediksi = $request->triwulan;
                $data = explode(' ', $dataprediksi);
                $triwulan = $data[0]; // Q1
                $tahun = $data[1]; // 2023
                if ($triwulan == 'Q1') {
                    $triwulandepan = 'Q2';
                    $tahundepan = $tahun;
                    $datatriwulandepan = 'Q2 ' . $tahundepan;
                    $tanggalawal = $tahun - 1 . '-12-31';
                    $tanggalakhir = $tahun . '-03-31';
                } elseif ($triwulan == 'Q2') {
                    $triwulandepan = 'Q3';
                    $tahundepan = $tahun;
                    $datatriwulandepan = 'Q3 ' . $tahundepan;
                    $tanggalawal = $tahun . '-03-31';
                    $tanggalakhir = $tahun . '-06-30';
                } elseif ($triwulan == 'Q3') {
                    $triwulandepan = 'Q4';
                    $tahundepan = $tahun;
                    $datatriwulandepan = 'Q4' . $tahundepan;
                    $tanggalawal = $tahun . '-06-30';
                    $tanggalakhir = $tahun . '-09-30';
                } elseif ($triwulan == 'Q4') {
                    $triwulandepan = 'Q1';
                    $tahundepan = $tahun + 1;
                    $datatriwulandepan = 'Q1 ' . $tahundepan;
                    $tanggalawal = $tahun . '-09-30';
                    $tanggalakhir = $tahun . '-12-31';
                }

                $pengunjung = Pengunjung::whereBetween('bulan', [$tanggalawal, $tanggalakhir])->get();

                $months = [
                    '01' => 31,
                    '02' => ($tahun % 4 == 0) ? 29 : 28,
                    '03' => 31,
                    '04' => 30,
                    '05' => 31,
                    '06' => 30,
                    '07' => 31,
                    '08' => 31,
                    '09' => 30,
                    '10' => 31,
                    '11' => 30,
                    '12' => 31,
                ];

                $datapengunjung = [];
                $totalpengunjung = 0;
                if (count($pengunjung) == 0) {
                    return view('dashboards.perhitungan.index');
                }
                $x = 1;
                foreach ($pengunjung as $j => $p) {
                    $dataprediksi = $p->bulan;
                    $data = explode('-', $dataprediksi);
                    $tahun = $data[0];
                    $bulan = $data[1];
                    $jumlahhari = $months[$bulan];
                    $tempdatapengunjung = [];
                    $temptotalpengunjung = 0;

                    for ($j = 1; $j <= $jumlahhari; $j++) {
                        $tempdatapengunjung[$j] = $p['t' . $j];
                        $temptotalpengunjung += $p['t' . $j];
                    }
                    $datapengunjung[] = $tempdatapengunjung;
                    $totalpengunjung += $temptotalpengunjung;
                    $temppengunjung[$x] = $temptotalpengunjung;
                    $x++;
                }
                $datapengunjung = $temppengunjung;



                function frequency(array $values): array
                {
                    $frequencies = array();
                    foreach ($values as $value) {
                        if (!isset($frequencies[$value])) {
                            $frequencies[$value] = 1;
                        } else {
                            $frequencies[$value]++;
                        }
                    }
                    return $frequencies;
                }
                $hasilurut = frequency($datapengunjung);
                ksort($hasilurut);
                // dd($hasilurut);
                $allkeys = array_keys($hasilurut);
                $allvalues = array_values($hasilurut);
                $jumlah = array_sum(array_column($hasilurut, null));
                $looping = sizeof($allkeys);
                $permintaan = $allkeys;
                $frekuensi = $allvalues;
                $probability = [];
                $cumulative = [];
                for ($i = 0; $i < $looping; $i++) {
                    $probability[$i] =  $frekuensi[$i] / $jumlah;
                    if ($i === 0) {
                        $cumulative[$i] = $probability[$i];
                    } else {
                        $cumulative[$i] = $probability[$i] + $cumulative[$i - 1];
                    }
                }
                // dd($cumulative);
                $length = 0;
                for ($i = 0; $i < $looping; $i++) {
                    if ($length < strlen($cumulative[$i])) {
                        $length = strlen($cumulative[$i]) - 2;
                    }
                }

                $intervalawal = 0.001;
                $intervalbawah[0] = $intervalawal;
                $intervalatas[0] = $cumulative[0];
                for ($i = 1; $i < $looping; $i++) {
                    $intervalbawah[$i] =  $intervalatas[$i - 1] + $intervalawal;
                    $intervalatas[$i] =  $cumulative[$i];
                }

                // dd($intervalbawah,$intervalatas);
                $config = Config::first();
                $a = $config->a;
                $c = $config->c;
                $m = $config->m;
                $z0 = $config->z0;
                //  dd($config)
                $temprandom = [];
                $temprandom[0] = $z0;

                // $asd =0;
                for ($i = 1; $i <= 3; $i++) {
                    $temprandom[$i] = ($a * $temprandom[$i - 1] + $c) % $m;
                    $randomnumber[$i] = round($temprandom[$i] / $m, 5);
                }
                // dd($randomnumber);

                $hasilprediksi = [];
                for ($i = 1; $i <= 3; $i++) {
                    for ($j = 0; $j < $looping - 1; $j++) {
                        if ($randomnumber[$i] >= $intervalbawah[$j] && $randomnumber[$i] <= $intervalatas[$j]) {
                            $hasilprediksi[$i] = $allkeys[$j];
                        } elseif ($randomnumber[$i] >= $intervalatas[$j]) {
                            $hasilprediksi[$i] = $allkeys[$j + 1];
                        }
                    }
                }
                // dd($hasilprediksi);
                $totalprediksi = array_sum(array_column($hasilprediksi, null)); //mengambil total value
                // dd($totalprediksi);





                // dd($datatriwulandepan);

                if ($triwulandepan == 'Q1') {
                    $tanggalawaldepan = $tahun - 1 . '-12-31';
                    $tanggalakhirdepan = $tahun . '-03-31';
                } elseif ($triwulandepan == 'Q2') {
                    $tanggalawaldepan = $tahun . '-03-31';
                    $tanggalakhirdepan = $tahun . '-06-30';
                } elseif ($triwulandepan == 'Q3') {
                    $tanggalawaldepan = $tahun . '-06-30';
                    $tanggalakhirdepan = $tahun . '-09-30';
                } elseif ($triwulandepan == 'Q4') {
                    $tanggalawaldepan = $tahun . '-09-30';
                    $tanggalakhirdepan = $tahun . '-12-31';
                }
                // dd($datatriwulandepan,$tanggalawaldepan,$tanggalakhirdepan); 

                $cekdataasli = Pengunjung::whereBetween('bulan', [$tanggalawaldepan, $tanggalakhirdepan])->get();

                $dataasli = [];
                $ape = [];
                $totalape = 0;
                if (count($cekdataasli) == 3) {
                    // dd("df");
                    $totaldataasli = 0;
                    $x = 1;
                    foreach ($cekdataasli as $j => $p) {
                        $dataprediksi = $p->bulan;
                        $data = explode('-', $dataprediksi);
                        $tahun = $data[0];
                        $bulan = $data[1];
                        $jumlahhari = $months[$bulan];
                        $tempdatacekdataasli = [];
                        $temptotalcekdataasli = 0;

                        for ($j = 1; $j <= $jumlahhari; $j++) {
                            $tempdatacekdataasli[$j] = $p['t' . $j];
                            $temptotalcekdataasli += $p['t' . $j];
                        }
                        $datacekdataasli[] = $tempdatacekdataasli;
                        $temptotalcekdataasli += $temptotalcekdataasli;
                        $tempcekdataasli[$x] = $temptotalcekdataasli;
                        $x++;
                    }
                    // dd($tempcekdataasli);
                    for ($i = 1; $i <=  3; $i++) {
                        $dataasli[$i] =  $tempcekdataasli[$i];
                        $ape[$i] = $dataasli[$i] == 0 ?: (($dataasli[$i] - $hasilprediksi[$i]) /  $dataasli[$i]) * 100;
                        $totalape +=  $ape[$i];
                        $totaldataasli +=  $dataasli[$i];
                    }
                    $mape = $totalape / 3;
                    $hasil = new hasil();
                    $hasil->pengunjung_id = 1;
                    $hasil->data_prediksi = $dataprediksi;
                    $data = [ 
                        'dataprediksi' => $dataprediksi,
                        'hasilprediksi' => $hasilprediksi,
                        'totalprediksi' => $totalprediksi,
                        'dataasli' => $dataasli,
                        'totaldataasli' => $totaldataasli,
                        'ape' => $ape,
                        'mape' => $mape,
                    ];
                    $hasil->mape = json_encode($data);
                    $hasil->save();
                    // dd($pengunjung->id);
                    // dd($hasil);
                    return view('dashboards.perhitungan.index', compact('jumlahhari', 'datapengunjung', 'totalpengunjung', 'pengunjung', 'allkeys', 'allvalues', 'jumlah', 'looping', 'probability', 'cumulative', 'intervalbawah', 'intervalatas', 'randomnumber', 'hasilprediksi', 'totalprediksi', 'dataasli', 'cekdataasli',   'ape', 'mape', 'totaldataasli'));
                } else {
                    $dataaslibelumada = true;
                    return view('dashboards.perhitungan.index', compact('jumlahhari', 'datapengunjung', 'totalpengunjung', 'pengunjung', 'allkeys', 'allvalues', 'jumlah', 'looping', 'probability', 'cumulative', 'intervalbawah', 'intervalatas', 'randomnumber', 'hasilprediksi', 'totalprediksi', 'dataasli', 'cekdataasli',   'ape',   'dataaslibelumada'));
                }
            } else {
                return view('dashboards.perhitungan.index', compact('pengunjung'));
            }
        }
    }
    public function print(Request $request)
    {
        $data = $request->all();
        // dd($data);
        $pdf = PDF::loadView('dashboards.perhitungan.print', compact('data'))->setPaper('a4');
        return $pdf->stream('print');
    }
}
