<?php

namespace App\Http\Controllers;
use App\Models\Config;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ConfigController extends Controller
{
     
    public function edit(Request $request)
    {
        $config = Config::first();
        return view('dashboards.config', compact('config'));
    }
    public function update(Request $request)
    {
            $config = config::first(); 
            $this->validate($request, [
                'z0' => 'required|numeric|min:1',
                'a' => 'required|numeric|min:1',
                'c' => 'required|numeric|min:1',
                'm' => 'required|numeric|min:1|gt:a|gt:c|gt:z0',
            ]);
            $config->z0 = $request->z0;
            $config->a = $request->a;
            $config->c = $request->c;
            $config->m = $request->m;
            $config->save();
        toast('Config update successfully', 'success');

            return view('dashboards.config', compact('config'));
    }
}
