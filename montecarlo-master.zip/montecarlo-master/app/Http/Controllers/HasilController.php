<?php

namespace App\Http\Controllers;

use App\Models\Hasil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class HasilController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hasil = hasil::get();
        return view('dashboards.hasil.index', compact('hasil'));
    }
    public function show($id)
    {
        $hasil = hasil::findorfail($id); 
        return view('dashboards.hasil.view', compact('hasil'));
    }
    public function destroy($id)
    {
        $hasil = hasil::where('id', $id)->get();
        $hasil->each->delete();
        toast('hasil deleted successfully', 'success');

        return redirect('/dashboards/hasil');
    }
}
