<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pengunjung;
class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $bulan = "2023-01"; // Change this to the month you want to query
        $pengunjung = pengunjung::where('bulan', $bulan)->first();
        
        $sold = 0;
        if ($pengunjung) {
            for ($i = 1; $i <= 31; $i++) {
                $sold += $pengunjung['t' . $i];
            }
        }
        
        return view('dashboards.dashboards');

    }
}
