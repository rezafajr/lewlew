<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ConfigController;
use App\Http\Controllers\PengunjungController;
use App\Http\Controllers\PerhitunganController;
use App\Http\Controllers\HasilController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::group(['middleware' => 'checklevel:1,2' ], function() {
    Route::get('/dashboards', [DashboardController::class, 'index']); 
    Route::resource('/dashboards/pengunjung', PengunjungController::class);
    Route::get('/dashboards/perhitungan/hasil', [PerhitunganController::class, 'hasil']);
    Route::get('/dashboards/perhitungan/hitung', [PerhitunganController::class, 'hitung']);
    Route::get('/dashboards/perhitungan/print', [PerhitunganController::class, 'print']);
    Route::resource('/dashboards/perhitungan', PerhitunganController::class);
    Route::resource('/dashboards/hasil', HasilController::class)->except([
        'create', 'update', 
    ]);
    Route::get('/dashboards/perhitungan/print', [PerhitunganController::class, 'print']);
});

Route::group(['middleware' => 'checklevel:1' ], function() {
    Route::get('/dashboards/config', [ConfigController::class, 'edit']);
    Route::patch('/dashboards/config', [ConfigController::class, 'update']);
    Route::resource('/dashboards/users',UserController::class);
});
