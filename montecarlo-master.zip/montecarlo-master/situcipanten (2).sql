-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2023 at 09:18 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `situcipanten`
--

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `z0` int(11) NOT NULL,
  `a` int(11) NOT NULL,
  `c` int(11) NOT NULL,
  `m` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `z0`, `a`, `c`, `m`, `created_at`, `updated_at`) VALUES
(1, 3, 5, 9, 19, '2023-11-10 18:56:45', '2023-11-10 18:56:45');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hasil`
--

CREATE TABLE `hasil` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pengunjung_id` bigint(20) UNSIGNED NOT NULL,
  `data_prediksi` varchar(255) NOT NULL,
  `mape` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `hasil`
--

INSERT INTO `hasil` (`id`, `pengunjung_id`, `data_prediksi`, `mape`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-01', '{\"dataprediksi\":\"2023-01\",\"hasilprediksi\":{\"1\":151,\"2\":784,\"3\":173,\"4\":311,\"5\":163,\"6\":154,\"7\":54,\"8\":616,\"9\":105,\"10\":151,\"11\":784,\"12\":173,\"13\":311,\"14\":163,\"15\":154,\"16\":54,\"17\":616,\"18\":105,\"19\":151,\"20\":784,\"21\":173,\"22\":311,\"23\":163,\"24\":154,\"25\":54,\"26\":616,\"27\":105,\"28\":151},\"totalprediksi\":7684,\"dataasli\":{\"1\":137,\"2\":127,\"3\":86,\"4\":317,\"5\":702,\"6\":136,\"7\":131,\"8\":114,\"9\":116,\"10\":89,\"11\":234,\"12\":572,\"13\":139,\"14\":124,\"15\":125,\"16\":143,\"17\":81,\"18\":695,\"19\":695,\"20\":111,\"21\":82,\"22\":100,\"23\":96,\"24\":30,\"25\":246,\"26\":600,\"27\":10,\"28\":68},\"totaldataasli\":6106,\"ape\":{\"1\":-10.218978102189782,\"2\":-517.3228346456692,\"3\":-101.16279069767442,\"4\":1.8927444794952681,\"5\":76.78062678062678,\"6\":-13.23529411764706,\"7\":58.778625954198475,\"8\":-440.35087719298247,\"9\":9.482758620689655,\"10\":-69.66292134831461,\"11\":-235.04273504273505,\"12\":69.75524475524476,\"13\":-123.74100719424462,\"14\":-31.451612903225808,\"15\":-23.200000000000003,\"16\":62.23776223776224,\"17\":-660.4938271604939,\"18\":84.89208633093526,\"19\":78.27338129496403,\"20\":-606.3063063063063,\"21\":-110.97560975609757,\"22\":-211,\"23\":-69.79166666666666,\"24\":-413.33333333333337,\"25\":78.04878048780488,\"26\":-2.666666666666667,\"27\":-950,\"28\":-122.05882352941177},\"mape\":-149.7097597757835}', '2023-11-10 18:59:50', '2023-11-10 18:59:50'),
(2, 1, '2023-06', '{\"dataprediksi\":\"2023-06\",\"hasilprediksi\":{\"1\":6106,\"2\":18343,\"3\":6577},\"totalprediksi\":31026,\"dataasli\":{\"1\":63288,\"2\":18700,\"3\":16264},\"totaldataasli\":98252,\"ape\":{\"1\":90.35204146125648,\"2\":1.9090909090909092,\"3\":59.560993605509104},\"mape\":50.607375325285496}', '2023-11-10 20:02:38', '2023-11-10 20:02:38'),
(3, 1, '2023-09', '{\"dataprediksi\":\"2023-09\",\"hasilprediksi\":{\"1\":8132,\"2\":31644,\"3\":9350},\"totalprediksi\":49126,\"dataasli\":{\"1\":21874,\"2\":7544,\"3\":7960},\"totaldataasli\":37378,\"ape\":{\"1\":62.823443357410625,\"2\":-319.4591728525981,\"3\":-17.462311557788944},\"mape\":-91.36601368432548}', '2023-11-10 20:04:31', '2023-11-10 20:04:31'),
(4, 1, '2023-01', '{\"dataprediksi\":\"2023-01\",\"hasilprediksi\":{\"1\":151,\"2\":885,\"3\":173,\"4\":385,\"5\":163,\"6\":154,\"7\":82,\"8\":621,\"9\":110,\"10\":151,\"11\":885,\"12\":173,\"13\":385,\"14\":163,\"15\":154,\"16\":82,\"17\":621,\"18\":110,\"19\":151,\"20\":885,\"21\":173,\"22\":385,\"23\":163,\"24\":154,\"25\":82,\"26\":621,\"27\":110,\"28\":151},\"totalprediksi\":8323,\"dataasli\":{\"1\":137,\"2\":127,\"3\":86,\"4\":317,\"5\":702,\"6\":136,\"7\":131,\"8\":114,\"9\":116,\"10\":89,\"11\":234,\"12\":572,\"13\":139,\"14\":124,\"15\":125,\"16\":143,\"17\":81,\"18\":695,\"19\":695,\"20\":111,\"21\":82,\"22\":100,\"23\":96,\"24\":30,\"25\":246,\"26\":600,\"27\":10,\"28\":68},\"totaldataasli\":6106,\"ape\":{\"1\":-10.218978102189782,\"2\":-596.8503937007874,\"3\":-101.16279069767442,\"4\":-21.451104100946374,\"5\":76.78062678062678,\"6\":-13.23529411764706,\"7\":37.404580152671755,\"8\":-444.7368421052632,\"9\":5.172413793103448,\"10\":-69.66292134831461,\"11\":-278.2051282051282,\"12\":69.75524475524476,\"13\":-176.97841726618705,\"14\":-31.451612903225808,\"15\":-23.200000000000003,\"16\":42.65734265734265,\"17\":-666.6666666666667,\"18\":84.17266187050359,\"19\":78.27338129496403,\"20\":-697.2972972972973,\"21\":-110.97560975609757,\"22\":-285,\"23\":-69.79166666666666,\"24\":-413.33333333333337,\"25\":66.66666666666666,\"26\":-3.5000000000000004,\"27\":-1000,\"28\":-122.05882352941177},\"mape\":-166.9604986366326}', '2023-11-10 20:07:44', '2023-11-10 20:07:44'),
(5, 1, '2023-01', '{\"dataprediksi\":\"2023-01\",\"hasilprediksi\":{\"1\":151,\"2\":885,\"3\":173,\"4\":385,\"5\":163,\"6\":154,\"7\":82,\"8\":621,\"9\":110,\"10\":151,\"11\":885,\"12\":173,\"13\":385,\"14\":163,\"15\":154,\"16\":82,\"17\":621,\"18\":110,\"19\":151,\"20\":885,\"21\":173,\"22\":385,\"23\":163,\"24\":154,\"25\":82,\"26\":621,\"27\":110,\"28\":151},\"totalprediksi\":8323,\"dataasli\":{\"1\":137,\"2\":127,\"3\":86,\"4\":317,\"5\":702,\"6\":136,\"7\":131,\"8\":114,\"9\":116,\"10\":89,\"11\":234,\"12\":572,\"13\":139,\"14\":124,\"15\":125,\"16\":143,\"17\":81,\"18\":695,\"19\":695,\"20\":111,\"21\":82,\"22\":100,\"23\":96,\"24\":30,\"25\":246,\"26\":600,\"27\":10,\"28\":68},\"totaldataasli\":6106,\"ape\":{\"1\":-10.218978102189782,\"2\":-596.8503937007874,\"3\":-101.16279069767442,\"4\":-21.451104100946374,\"5\":76.78062678062678,\"6\":-13.23529411764706,\"7\":37.404580152671755,\"8\":-444.7368421052632,\"9\":5.172413793103448,\"10\":-69.66292134831461,\"11\":-278.2051282051282,\"12\":69.75524475524476,\"13\":-176.97841726618705,\"14\":-31.451612903225808,\"15\":-23.200000000000003,\"16\":42.65734265734265,\"17\":-666.6666666666667,\"18\":84.17266187050359,\"19\":78.27338129496403,\"20\":-697.2972972972973,\"21\":-110.97560975609757,\"22\":-285,\"23\":-69.79166666666666,\"24\":-413.33333333333337,\"25\":66.66666666666666,\"26\":-3.5000000000000004,\"27\":-1000,\"28\":-122.05882352941177},\"mape\":-166.9604986366326}', '2023-11-10 20:13:17', '2023-11-10 20:13:17'),
(6, 1, '2023-01', '{\"dataprediksi\":\"2023-01\",\"hasilprediksi\":{\"1\":151,\"2\":885,\"3\":173,\"4\":385,\"5\":163,\"6\":154,\"7\":82,\"8\":621,\"9\":110,\"10\":151,\"11\":885,\"12\":173,\"13\":385,\"14\":163,\"15\":154,\"16\":82,\"17\":621,\"18\":110,\"19\":151,\"20\":885,\"21\":173,\"22\":385,\"23\":163,\"24\":154,\"25\":82,\"26\":621,\"27\":110,\"28\":151},\"totalprediksi\":8323,\"dataasli\":{\"1\":137,\"2\":127,\"3\":86,\"4\":317,\"5\":702,\"6\":136,\"7\":131,\"8\":114,\"9\":116,\"10\":89,\"11\":234,\"12\":572,\"13\":139,\"14\":124,\"15\":125,\"16\":143,\"17\":81,\"18\":695,\"19\":695,\"20\":111,\"21\":82,\"22\":100,\"23\":96,\"24\":30,\"25\":246,\"26\":600,\"27\":10,\"28\":68},\"totaldataasli\":6106,\"ape\":{\"1\":-10.218978102189782,\"2\":-596.8503937007874,\"3\":-101.16279069767442,\"4\":-21.451104100946374,\"5\":76.78062678062678,\"6\":-13.23529411764706,\"7\":37.404580152671755,\"8\":-444.7368421052632,\"9\":5.172413793103448,\"10\":-69.66292134831461,\"11\":-278.2051282051282,\"12\":69.75524475524476,\"13\":-176.97841726618705,\"14\":-31.451612903225808,\"15\":-23.200000000000003,\"16\":42.65734265734265,\"17\":-666.6666666666667,\"18\":84.17266187050359,\"19\":78.27338129496403,\"20\":-697.2972972972973,\"21\":-110.97560975609757,\"22\":-285,\"23\":-69.79166666666666,\"24\":-413.33333333333337,\"25\":66.66666666666666,\"26\":-3.5000000000000004,\"27\":-1000,\"28\":-122.05882352941177},\"mape\":-166.9604986366326}', '2023-11-10 20:20:51', '2023-11-10 20:20:51'),
(7, 1, '2023-01', '{\"dataprediksi\":\"2023-01\",\"hasilprediksi\":{\"1\":151,\"2\":885,\"3\":173,\"4\":385,\"5\":163,\"6\":154,\"7\":82,\"8\":621,\"9\":110,\"10\":151,\"11\":885,\"12\":173,\"13\":385,\"14\":163,\"15\":154,\"16\":82,\"17\":621,\"18\":110,\"19\":151,\"20\":885,\"21\":173,\"22\":385,\"23\":163,\"24\":154,\"25\":82,\"26\":621,\"27\":110,\"28\":151},\"totalprediksi\":8323,\"dataasli\":{\"1\":137,\"2\":127,\"3\":86,\"4\":317,\"5\":702,\"6\":136,\"7\":131,\"8\":114,\"9\":116,\"10\":89,\"11\":234,\"12\":572,\"13\":139,\"14\":124,\"15\":125,\"16\":143,\"17\":81,\"18\":695,\"19\":695,\"20\":111,\"21\":82,\"22\":100,\"23\":96,\"24\":30,\"25\":246,\"26\":600,\"27\":10,\"28\":68},\"totaldataasli\":6106,\"ape\":{\"1\":-10.218978102189782,\"2\":-596.8503937007874,\"3\":-101.16279069767442,\"4\":-21.451104100946374,\"5\":76.78062678062678,\"6\":-13.23529411764706,\"7\":37.404580152671755,\"8\":-444.7368421052632,\"9\":5.172413793103448,\"10\":-69.66292134831461,\"11\":-278.2051282051282,\"12\":69.75524475524476,\"13\":-176.97841726618705,\"14\":-31.451612903225808,\"15\":-23.200000000000003,\"16\":42.65734265734265,\"17\":-666.6666666666667,\"18\":84.17266187050359,\"19\":78.27338129496403,\"20\":-697.2972972972973,\"21\":-110.97560975609757,\"22\":-285,\"23\":-69.79166666666666,\"24\":-413.33333333333337,\"25\":66.66666666666666,\"26\":-3.5000000000000004,\"27\":-1000,\"28\":-122.05882352941177},\"mape\":-166.9604986366326}', '2023-11-10 20:21:04', '2023-11-10 20:21:04'),
(8, 1, '2023-01', '{\"dataprediksi\":\"2023-01\",\"hasilprediksi\":{\"1\":151,\"2\":885,\"3\":173,\"4\":385,\"5\":163,\"6\":154,\"7\":82,\"8\":621,\"9\":110,\"10\":151,\"11\":885,\"12\":173,\"13\":385,\"14\":163,\"15\":154,\"16\":82,\"17\":621,\"18\":110,\"19\":151,\"20\":885,\"21\":173,\"22\":385,\"23\":163,\"24\":154,\"25\":82,\"26\":621,\"27\":110,\"28\":151},\"totalprediksi\":8323,\"dataasli\":{\"1\":137,\"2\":127,\"3\":86,\"4\":317,\"5\":702,\"6\":136,\"7\":131,\"8\":114,\"9\":116,\"10\":89,\"11\":234,\"12\":572,\"13\":139,\"14\":124,\"15\":125,\"16\":143,\"17\":81,\"18\":695,\"19\":695,\"20\":111,\"21\":82,\"22\":100,\"23\":96,\"24\":30,\"25\":246,\"26\":600,\"27\":10,\"28\":68},\"totaldataasli\":6106,\"ape\":{\"1\":-10.218978102189782,\"2\":-596.8503937007874,\"3\":-101.16279069767442,\"4\":-21.451104100946374,\"5\":76.78062678062678,\"6\":-13.23529411764706,\"7\":37.404580152671755,\"8\":-444.7368421052632,\"9\":5.172413793103448,\"10\":-69.66292134831461,\"11\":-278.2051282051282,\"12\":69.75524475524476,\"13\":-176.97841726618705,\"14\":-31.451612903225808,\"15\":-23.200000000000003,\"16\":42.65734265734265,\"17\":-666.6666666666667,\"18\":84.17266187050359,\"19\":78.27338129496403,\"20\":-697.2972972972973,\"21\":-110.97560975609757,\"22\":-285,\"23\":-69.79166666666666,\"24\":-413.33333333333337,\"25\":66.66666666666666,\"26\":-3.5000000000000004,\"27\":-1000,\"28\":-122.05882352941177},\"mape\":-166.9604986366326}', '2023-11-17 22:22:58', '2023-11-17 22:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_11_01_220738_create_pengunjung_table', 1),
(6, '2023_11_01_371481_create_config_table', 1),
(7, '2023_11_02_241248_create_hasil_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengunjung`
--

CREATE TABLE `pengunjung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bulan` varchar(255) NOT NULL,
  `t1` int(11) DEFAULT NULL,
  `t2` int(11) DEFAULT NULL,
  `t3` int(11) DEFAULT NULL,
  `t4` int(11) DEFAULT NULL,
  `t5` int(11) DEFAULT NULL,
  `t6` int(11) DEFAULT NULL,
  `t7` int(11) DEFAULT NULL,
  `t8` int(11) DEFAULT NULL,
  `t9` int(11) DEFAULT NULL,
  `t10` int(11) DEFAULT NULL,
  `t11` int(11) DEFAULT NULL,
  `t12` int(11) DEFAULT NULL,
  `t13` int(11) DEFAULT NULL,
  `t14` int(11) DEFAULT NULL,
  `t15` int(11) DEFAULT NULL,
  `t16` int(11) DEFAULT NULL,
  `t17` int(11) DEFAULT NULL,
  `t18` int(11) DEFAULT NULL,
  `t19` int(11) DEFAULT NULL,
  `t20` int(11) DEFAULT NULL,
  `t21` int(11) DEFAULT NULL,
  `t22` int(11) DEFAULT NULL,
  `t23` int(11) DEFAULT NULL,
  `t24` int(11) DEFAULT NULL,
  `t25` int(11) DEFAULT NULL,
  `t26` int(11) DEFAULT NULL,
  `t27` int(11) DEFAULT NULL,
  `t28` int(11) DEFAULT NULL,
  `t29` int(11) DEFAULT NULL,
  `t30` int(11) DEFAULT NULL,
  `t31` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengunjung`
--

INSERT INTO `pengunjung` (`id`, `bulan`, `t1`, `t2`, `t3`, `t4`, `t5`, `t6`, `t7`, `t8`, `t9`, `t10`, `t11`, `t12`, `t13`, `t14`, `t15`, `t16`, `t17`, `t18`, `t19`, `t20`, `t21`, `t22`, `t23`, `t24`, `t25`, `t26`, `t27`, `t28`, `t29`, `t30`, `t31`, `created_at`, `updated_at`) VALUES
(1, '2023-01', 3950, 1393, 784, 885, 616, 554, 1004, 1546, 251, 162, 173, 120, 154, 602, 1500, 169, 145, 105, 151, 89, 385, 1268, 621, 311, 82, 163, 54, 300, 575, 110, 121, NULL, '2023-11-10 19:12:00'),
(2, '2023-02', 137, 127, 86, 317, 702, 136, 131, 114, 116, 89, 234, 572, 139, 124, 125, 143, 81, 695, 695, 111, 82, 100, 96, 30, 246, 600, 10, 68, 0, 0, 0, NULL, NULL),
(3, '2023-03', 111, 111, 172, 373, 510, 153, 142, 64, 127, 61, 457, 1050, 143, 420, 132, 203, 142, 305, 577, 190, 292, 462, 48, 41, 21, 89, 15, 33, 18, 35, 80, NULL, '2023-11-10 19:14:09'),
(4, '2023-04', 1662, 1875, 598, 201, 747, 119, 1214, 1747, 1179, 328, 750, 320, 326, 314, 1606, 1495, 890, 290, 1516, 1437, 1481, 1771, 1919, 1688, 1317, 352, 884, 371, 1751, 1496, NULL, '2023-11-10 19:29:53', '2023-11-10 19:29:53'),
(5, '2023-05', 494, 299, 130, 276, 261, 255, 320, 210, 229, 195, 284, 282, 327, 467, 234, 251, 288, 468, 276, 474, 440, 234, 354, 176, 274, 277, 449, 478, 237, 244, 167, '2023-11-10 19:35:27', '2023-11-10 19:39:42'),
(6, '2023-07', 414, 461, 241, 169, 307, 220, 294, 481, 558, 322, 357, 197, 211, 298, 391, 632, 188, 149, 490, 231, 399, 583, 587, 367, 189, 282, 239, 187, 598, 732, 163, '2023-11-10 19:43:49', '2023-11-10 19:45:43'),
(7, '2023-06', 328, 361, 419, 300, 144, 187, 132, 245, 299, 427, 350, 167, 131, 181, 259, 137, 328, 498, 208, 179, 126, 219, 200, 334, 453, 311, 202, 302, 459, 246, NULL, '2023-11-10 19:48:43', '2023-11-10 19:49:58'),
(8, '2023-08', 79, 73, 62, 97, 176, 198, 94, 70, 68, 89, 82, 214, 260, 134, 64, 83, 289, 107, 157, 149, 65, 96, 122, 88, 84, 176, 237, 132, 63, 77, 87, '2023-11-10 19:53:13', '2023-11-10 19:53:13'),
(9, '2023-09', 84, 178, 176, 121, 105, 140, 152, 97, 189, 182, 158, 97, 82, 67, 78, 168, 188, 59, 67, 96, 143, 131, 232, 182, 101, 51, 163, 193, 102, 198, NULL, '2023-11-10 19:55:59', '2023-11-10 19:55:59'),
(10, '2023-10', 162, 97, 100, 140, 108, 94, 229, 246, 121, 154, 104, 74, 82, 219, 271, 122, 88, 164, 172, 187, 250, 199, 160, 176, 127, 163, 123, 217, 197, 98, 77, '2023-11-10 19:59:07', '2023-11-10 19:59:07');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` int(11) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `level`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin@gmail.com', '$2y$10$QyiCwe2z8uWrJtfZfJydkeMvSyf6WQoFsPZ8jXpJNVATPj/c4fWiu', 1, NULL, NULL, NULL),
(2, 'Pengguna', 'user@gmail.com', '$2y$10$ApcPncMoCvoGFe.BiHxh5.w4YGuCFMilkyUHrJ27Nroh6oJTUVUq6', 2, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hasil_pengunjung_id_foreign` (`pengunjung_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `pengunjung`
--
ALTER TABLE `pengunjung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hasil`
--
ALTER TABLE `hasil`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pengunjung`
--
ALTER TABLE `pengunjung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hasil`
--
ALTER TABLE `hasil`
  ADD CONSTRAINT `hasil_pengunjung_id_foreign` FOREIGN KEY (`pengunjung_id`) REFERENCES `pengunjung` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
